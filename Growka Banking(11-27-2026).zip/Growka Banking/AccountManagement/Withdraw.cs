﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountManagement
{
    public class Withdraw
    {
        private AccountManager accountManager;

        public Withdraw(AccountManager accountManager)
        {
            this.accountManager = accountManager;
        }

        public bool ProcessWithdraw(string accountNumber, decimal amount)
        {
            // Find the account
            Account account = accountManager.GetAccountByNumber(accountNumber);

            // Check if account exists
            if (account == null)
            {
                return false;
            }

            // Get the account
            // Process withdraw
            bool success = account.Withdraw(amount);

            if (!success)
                return false;

            accountManager.AddTransaction(account.AccountNumber, "Withdraw", amount, "Cash");

            return success;
        }
    }
}
