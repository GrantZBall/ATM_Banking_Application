﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace AccountManagement
{
    public class Account
    {
        // Initialize Variables with Get: AND Set: so I can auto set them later
        public string AccountNumber { get; set; }
        public string CustomerName { get; set; }
        public decimal Balance { get; set; }
        public decimal MinimumBalance { get; set; }
        public DateTime DateCreated { get; set; }
        public List<Transaction> Transactions { get; set; }

        // Executing the empty Account() to reserve memory space
        public Account() { Transactions = new List<Transaction>(); }
        
        // Creating the account instantance
        public Account(
            string accountNumberInput, 
            string customerNameInput, 
            decimal initialDepositInput, 
            decimal minimumBalanceInput)
        {
            AccountNumber = accountNumberInput;
            CustomerName = customerNameInput;
            Balance = initialDepositInput;
            MinimumBalance = minimumBalanceInput;
            DateCreated = DateTime.Now;
            Transactions = new List<Transaction>();
        }

        // Deposit function that returns boolean to confirm success / fail
        public bool Deposit(decimal depositAmountInput)
        {
            if (depositAmountInput <= 0)
                return false;
            Balance += depositAmountInput;
            return true;
        }

        // Withdraw function that checks if going below minimum balance and returns boolean to confirm success / fail
        public bool Withdraw(decimal withdrawAmountInput)
        {
            if (withdrawAmountInput <= 0 || (Balance -  withdrawAmountInput) <= MinimumBalance)
                return false;
            Balance -= withdrawAmountInput;
            return true;
        }
    }
}
