﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountManagement
{
    public class Deposit
    {
        private AccountManager accountManager;

        public Deposit(AccountManager accountManager)
        {
            this.accountManager = accountManager;
        }

        public bool ProcessDeposit(string accountNumber, decimal amount)
        {
            // Find the account
            Account account = accountManager.GetAccountByNumber(accountNumber);

            // Check if account exists
            if (account == null)
            {
                return false;
            }

            // Get the account
            // Process deposit
            bool success = account.Deposit(amount);

            if (!success)
                return false;

            accountManager.AddTransaction(account.AccountNumber, "Deposit", amount, "Checking");

            return success;
        }
    }
}
