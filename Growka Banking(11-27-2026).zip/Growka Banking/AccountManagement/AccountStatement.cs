using System;
using System.Linq;
using System.Text;

namespace AccountManagement
{
    // Creates a readable statement for an account.
    public class AccountStatement
    {
        private readonly AccountManager accountManager;
        private readonly TransactionHistory history;

        public AccountStatement(AccountManager accountManager)
        {
            this.accountManager = accountManager;
            history = new TransactionHistory(accountManager);
        }

        public string GenerateStatement(string accountNumber)
        {
            Account account = accountManager.GetAccountByNumber(accountNumber);
            if (account == null)
                return "Account not found.";

            var transactions = history.SearchHistory(accountNumber);
            StringBuilder statement = new StringBuilder();
            statement.AppendLine("ACCOUNT STATEMENT");
            statement.AppendLine("Customer: " + account.CustomerName);
            statement.AppendLine("Account Number: " + account.AccountNumber);
            statement.AppendLine("Date Created: " + account.DateCreated.ToString("g"));
            statement.AppendLine("Current Balance: " + account.Balance.ToString("C"));
            statement.AppendLine("--------------------------------------------------");

            foreach (Transaction transaction in transactions.OrderBy(t => t.Date))
            {
                statement.AppendLine(transaction.Date.ToString("g") + " | " + transaction.Type +
                    " | " + transaction.Amount.ToString("C") + " | " + transaction.Destination);
            }

            statement.AppendLine("--------------------------------------------------");
            statement.AppendLine("Total Deposits: " + history.GetTotalDeposits(accountNumber).ToString("C"));
            statement.AppendLine("Total Withdrawals: " + history.GetTotalWithdrawals(accountNumber).ToString("C"));
            statement.AppendLine("Number of Transactions: " + transactions.Count);
            return statement.ToString();
        }
    }
}
