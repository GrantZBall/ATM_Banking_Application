﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

namespace AccountManagement
{
    public class Transfer
    {
        private AccountManager accountManager;

        public Transfer(AccountManager accountManager)
        {
            this.accountManager = accountManager;
        }

        public bool ProcessTransfer(
            string senderAccountNumber,
            string receiverAccountNumber,
            decimal amount)
        {
            // Check that the amount is positive
            if (amount <= 0)
            {
                return false;
            }

            // Prevent transferring to the same account 
            if (senderAccountNumber == receiverAccountNumber)
            {
                return false;
            }

            //Find the sending account
            Account sender = accountManager.GetAccountByNumber(senderAccountNumber);

            //Find the receiving account
            Account receiver = accountManager.GetAccountByNumber(receiverAccountNumber);

            //Check that both accounts exist
            if (sender == null || receiver == null)
            {
                return false;
            }

            // Withdraw from sender
            bool withdrawSuccess = sender.Withdraw(amount);

            if (!withdrawSuccess)
            {
                return false;
            }

            // Deposit into receiver
            bool depositSuccess = receiver.Deposit(amount);

            //Restore sender balance if deposit fails
            if (!depositSuccess)
            {
                sender.Deposit(amount);
                return false;
            }

            // Save the transfer in both accounts' histories.
            accountManager.AddTransaction(sender.AccountNumber, "Transfer", amount, receiver.AccountNumber);
            accountManager.AddTransaction(receiver.AccountNumber, "Transfer In", amount, sender.AccountNumber);

            return true;
        }
    }
}
