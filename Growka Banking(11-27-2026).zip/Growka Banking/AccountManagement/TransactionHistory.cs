using System;
using System.Collections.Generic;
using System.Linq;

namespace AccountManagement
{
    // Finds transactions and calculates totals for one account.
    public class TransactionHistory
    {
        private readonly AccountManager accountManager;

        public TransactionHistory(AccountManager accountManager)
        {
            this.accountManager = accountManager;
        }

        public List<Transaction> SearchHistory(string accountNumber)
        {
            Account account = accountManager.GetAccountByNumber(accountNumber);
            if (account == null)
                return new List<Transaction>();

            return account.Transactions ?? new List<Transaction>();
        }

        public decimal GetTotalDeposits(string accountNumber)
        {
            return SearchHistory(accountNumber)
                .Where(t => t.Type == "Deposit" || t.Type == "Transfer In")
                .Sum(t => t.Amount);
        }

        public decimal GetTotalWithdrawals(string accountNumber)
        {
            return SearchHistory(accountNumber)
                .Where(t => t.Type == "Withdraw" || t.Type == "Transfer" || t.Type == "Transfer Out")
                .Sum(t => t.Amount);
        }
    }
}
