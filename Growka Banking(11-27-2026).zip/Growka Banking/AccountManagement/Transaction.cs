﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountManagement
{
    public class Transaction
    {
        public DateTime Date { get; set; }
        public string Type { get; set; }
        public decimal Amount { get; set; }

        public string Destination { get; set; }

        public Transaction() { }

        public Transaction(string type, decimal amount, string destination)
        {
            Type = type;
            Amount = amount;
            Destination = destination;
            Date = DateTime.Now;
        }
    }
}
