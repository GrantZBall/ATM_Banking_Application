﻿namespace AccountManagement
{
    partial class MainPage
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            WelcomeLbl = new Label();
            HomeGroupBox = new GroupBox();
            TransactionsPageButton = new Button();
            ViewAllAccountsPageButton = new Button();
            SearchAccountPageButton = new Button();
            CreateAccountPageButton = new Button();
            CreateAccountGroupBox = new GroupBox();
            CreateStatusLbl = new Label();
            CreateMinimumBalanceTextBox = new TextBox();
            CreateMinimumBalanceLbl = new Label();
            CreateInitialDepositTextBox = new TextBox();
            CreateInitialDepositLbl = new Label();
            CreateCustomerNameTextBox = new TextBox();
            CreateCustomerNameLbl = new Label();
            CreateHomeButton = new Button();
            CreateAccountButton = new Button();
            CreateAccountLbl = new Label();
            AllAccountsGroupbox = new GroupBox();
            AccountsGrid = new DataGridView();
            AllAccountsHomeButton = new Button();
            AllAccountsLbl = new Label();
            SearchAccountGroupBox = new GroupBox();
            SearchEnterIDORNameLbl = new Label();
            SearchAccountsGrid = new DataGridView();
            SearchStatusLbl = new Label();
            SearchCustomerNameTextbox = new TextBox();
            SearchBox = new Label();
            SearchHomeButton = new Button();
            SearchButton = new Button();
            SearchAccountLbl = new Label();
            TransactionsGroupBox = new GroupBox();
            TransferPageButton = new Button();
            WithdrawPageButton = new Button();
            DepositPageButton = new Button();
            TransactionHomeButton = new Button();
            DepositGroupBox = new GroupBox();
            DepositNewBalance = new Label();
            DepositOldBalanceLabel = new Label();
            DepositUpdatedBalanceLabel = new Label();
            DepositPreviousBalanceLabel = new Label();
            DepositStatusLabel = new Label();
            DepositButton = new Button();
            DepositAmountTextBox = new TextBox();
            DepositAccountNumberTextBox = new TextBox();
            DepositAmountLabel = new Label();
            DepositAccountNumberLabel = new Label();
            DepositBackButton = new Button();
            WithdrawGroupBox = new GroupBox();
            WithdrawUpdatedBalance = new Label();
            WithdrawPreviousBalance = new Label();
            WithdrawStatusLabel = new Label();
            WithdrawNewBalanceLabel = new Label();
            WithdrawOldBalanceLabel = new Label();
            WithdrawAmountTextBox = new TextBox();
            WithdrawAccountNumberTextBox = new TextBox();
            WithdrawAmountLabel = new Label();
            WithdrawAccountNumberLabel = new Label();
            WithdrawButton = new Button();
            WithdrawBackButton = new Button();
            TransferGroupBox = new GroupBox();
            TransferReceiverUpdatedBalance = new Label();
            TransferReceiverNewBalance = new Label();
            TransferReceiverPreviousBalance = new Label();
            TransferReceiverOldBalance = new Label();
            TransferSenderUpdatedBalance = new Label();
            TransferSenderNewBalance = new Label();
            TransferSenderPreviousBalance = new Label();
            TransferSenderOldBalanceLabel = new Label();
            TransferStatusLabel = new Label();
            TransferButton = new Button();
            TransferAmountTextBox = new TextBox();
            TransferAmountLabel = new Label();
            TransferReceiverAccountTextBox = new TextBox();
            TransferReceiverAccountLabel = new Label();
            TransferSenderAccountTextBox = new TextBox();
            TransferSenderAccountLabel = new Label();
            TransferBackButton = new Button();
            FullAccountDetails = new GroupBox();
            AccDetailsAccNum = new Label();
            AccDetailsDateCreated = new Label();
            AccDetailsMinBal = new Label();
            AccDetailsCurrentBal = new Label();
            AccDetailsCustomerName = new Label();
            label6 = new Label();
            AccDetailsTransactionGridBox = new DataGridView();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            AccDetailsBackButton = new Button();
            AccountDetailsLbl = new Label();
            HomeGroupBox.SuspendLayout();
            CreateAccountGroupBox.SuspendLayout();
            AllAccountsGroupbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)AccountsGrid).BeginInit();
            SearchAccountGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)SearchAccountsGrid).BeginInit();
            TransactionsGroupBox.SuspendLayout();
            DepositGroupBox.SuspendLayout();
            WithdrawGroupBox.SuspendLayout();
            TransferGroupBox.SuspendLayout();
            FullAccountDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)AccDetailsTransactionGridBox).BeginInit();
            SuspendLayout();
            // 
            // WelcomeLbl
            // 
            WelcomeLbl.AutoSize = true;
            WelcomeLbl.Font = new Font("Sylfaen", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            WelcomeLbl.Location = new Point(80, 76);
            WelcomeLbl.Name = "WelcomeLbl";
            WelcomeLbl.Size = new Size(391, 31);
            WelcomeLbl.TabIndex = 0;
            WelcomeLbl.Text = "Thank you for using ATM Banking";
            // 
            // HomeGroupBox
            // 
            HomeGroupBox.Controls.Add(TransactionsPageButton);
            HomeGroupBox.Controls.Add(ViewAllAccountsPageButton);
            HomeGroupBox.Controls.Add(SearchAccountPageButton);
            HomeGroupBox.Controls.Add(CreateAccountPageButton);
            HomeGroupBox.Controls.Add(WelcomeLbl);
            HomeGroupBox.Location = new Point(12, 12);
            HomeGroupBox.Name = "HomeGroupBox";
            HomeGroupBox.Size = new Size(557, 457);
            HomeGroupBox.TabIndex = 1;
            HomeGroupBox.TabStop = false;
            HomeGroupBox.Visible = false;
            // 
            // TransactionsPageButton
            // 
            TransactionsPageButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            TransactionsPageButton.Location = new Point(174, 168);
            TransactionsPageButton.Name = "TransactionsPageButton";
            TransactionsPageButton.Size = new Size(208, 43);
            TransactionsPageButton.TabIndex = 4;
            TransactionsPageButton.Text = "Transactions";
            TransactionsPageButton.UseVisualStyleBackColor = true;
            TransactionsPageButton.Click += TransactionsPageButton_Click;
            // 
            // ViewAllAccountsPageButton
            // 
            ViewAllAccountsPageButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewAllAccountsPageButton.Location = new Point(174, 267);
            ViewAllAccountsPageButton.Name = "ViewAllAccountsPageButton";
            ViewAllAccountsPageButton.Size = new Size(208, 43);
            ViewAllAccountsPageButton.TabIndex = 3;
            ViewAllAccountsPageButton.Text = "View All Accounts";
            ViewAllAccountsPageButton.UseVisualStyleBackColor = true;
            ViewAllAccountsPageButton.Click += ViewAllAccountsPageButton_Click;
            // 
            // SearchAccountPageButton
            // 
            SearchAccountPageButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchAccountPageButton.Location = new Point(174, 218);
            SearchAccountPageButton.Name = "SearchAccountPageButton";
            SearchAccountPageButton.Size = new Size(208, 43);
            SearchAccountPageButton.TabIndex = 2;
            SearchAccountPageButton.Text = "Search Account";
            SearchAccountPageButton.UseVisualStyleBackColor = true;
            SearchAccountPageButton.Click += SearchAccountPageButton_Click;
            // 
            // CreateAccountPageButton
            // 
            CreateAccountPageButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateAccountPageButton.Location = new Point(174, 119);
            CreateAccountPageButton.Name = "CreateAccountPageButton";
            CreateAccountPageButton.Size = new Size(208, 43);
            CreateAccountPageButton.TabIndex = 1;
            CreateAccountPageButton.Text = "Create Account";
            CreateAccountPageButton.UseVisualStyleBackColor = true;
            CreateAccountPageButton.Click += CreateAccountPageButton_Click;
            // 
            // CreateAccountGroupBox
            // 
            CreateAccountGroupBox.Controls.Add(CreateStatusLbl);
            CreateAccountGroupBox.Controls.Add(CreateMinimumBalanceTextBox);
            CreateAccountGroupBox.Controls.Add(CreateMinimumBalanceLbl);
            CreateAccountGroupBox.Controls.Add(CreateInitialDepositTextBox);
            CreateAccountGroupBox.Controls.Add(CreateInitialDepositLbl);
            CreateAccountGroupBox.Controls.Add(CreateCustomerNameTextBox);
            CreateAccountGroupBox.Controls.Add(CreateCustomerNameLbl);
            CreateAccountGroupBox.Controls.Add(CreateHomeButton);
            CreateAccountGroupBox.Controls.Add(CreateAccountButton);
            CreateAccountGroupBox.Controls.Add(CreateAccountLbl);
            CreateAccountGroupBox.Location = new Point(12, 12);
            CreateAccountGroupBox.Name = "CreateAccountGroupBox";
            CreateAccountGroupBox.Size = new Size(557, 457);
            CreateAccountGroupBox.TabIndex = 4;
            CreateAccountGroupBox.TabStop = false;
            CreateAccountGroupBox.Visible = false;
            // 
            // CreateStatusLbl
            // 
            CreateStatusLbl.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CreateStatusLbl.Location = new Point(6, 360);
            CreateStatusLbl.Name = "CreateStatusLbl";
            CreateStatusLbl.Size = new Size(545, 50);
            CreateStatusLbl.TabIndex = 11;
            CreateStatusLbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // CreateMinimumBalanceTextBox
            // 
            CreateMinimumBalanceTextBox.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CreateMinimumBalanceTextBox.Location = new Point(288, 218);
            CreateMinimumBalanceTextBox.Name = "CreateMinimumBalanceTextBox";
            CreateMinimumBalanceTextBox.PlaceholderText = "Ex. 200";
            CreateMinimumBalanceTextBox.Size = new Size(188, 33);
            CreateMinimumBalanceTextBox.TabIndex = 10;
            // 
            // CreateMinimumBalanceLbl
            // 
            CreateMinimumBalanceLbl.AutoSize = true;
            CreateMinimumBalanceLbl.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateMinimumBalanceLbl.Location = new Point(80, 221);
            CreateMinimumBalanceLbl.Name = "CreateMinimumBalanceLbl";
            CreateMinimumBalanceLbl.Size = new Size(202, 25);
            CreateMinimumBalanceLbl.TabIndex = 9;
            CreateMinimumBalanceLbl.Text = "Minimum Balance  . . .";
            // 
            // CreateInitialDepositTextBox
            // 
            CreateInitialDepositTextBox.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CreateInitialDepositTextBox.Location = new Point(288, 179);
            CreateInitialDepositTextBox.Name = "CreateInitialDepositTextBox";
            CreateInitialDepositTextBox.PlaceholderText = "Ex. 1500";
            CreateInitialDepositTextBox.Size = new Size(188, 33);
            CreateInitialDepositTextBox.TabIndex = 8;
            // 
            // CreateInitialDepositLbl
            // 
            CreateInitialDepositLbl.AutoSize = true;
            CreateInitialDepositLbl.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateInitialDepositLbl.Location = new Point(80, 182);
            CreateInitialDepositLbl.Name = "CreateInitialDepositLbl";
            CreateInitialDepositLbl.Size = new Size(202, 25);
            CreateInitialDepositLbl.TabIndex = 7;
            CreateInitialDepositLbl.Text = "Initial Deposit . . . . . . .";
            // 
            // CreateCustomerNameTextBox
            // 
            CreateCustomerNameTextBox.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CreateCustomerNameTextBox.Location = new Point(288, 138);
            CreateCustomerNameTextBox.Name = "CreateCustomerNameTextBox";
            CreateCustomerNameTextBox.PlaceholderText = "Ex. John Smith";
            CreateCustomerNameTextBox.Size = new Size(188, 33);
            CreateCustomerNameTextBox.TabIndex = 6;
            // 
            // CreateCustomerNameLbl
            // 
            CreateCustomerNameLbl.AutoSize = true;
            CreateCustomerNameLbl.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateCustomerNameLbl.Location = new Point(80, 141);
            CreateCustomerNameLbl.Name = "CreateCustomerNameLbl";
            CreateCustomerNameLbl.Size = new Size(202, 25);
            CreateCustomerNameLbl.TabIndex = 5;
            CreateCustomerNameLbl.Text = "Customer Name . . . . .";
            // 
            // CreateHomeButton
            // 
            CreateHomeButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateHomeButton.Location = new Point(6, 17);
            CreateHomeButton.Name = "CreateHomeButton";
            CreateHomeButton.Size = new Size(81, 43);
            CreateHomeButton.TabIndex = 4;
            CreateHomeButton.Text = "Home";
            CreateHomeButton.UseVisualStyleBackColor = true;
            CreateHomeButton.Click += CreateHomeButton_Click;
            // 
            // CreateAccountButton
            // 
            CreateAccountButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateAccountButton.Location = new Point(174, 287);
            CreateAccountButton.Name = "CreateAccountButton";
            CreateAccountButton.Size = new Size(208, 43);
            CreateAccountButton.TabIndex = 1;
            CreateAccountButton.Text = "Create Account";
            CreateAccountButton.UseVisualStyleBackColor = true;
            CreateAccountButton.Click += CreateAccountButton_Click;
            // 
            // CreateAccountLbl
            // 
            CreateAccountLbl.AutoSize = true;
            CreateAccountLbl.Font = new Font("Sylfaen", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateAccountLbl.Location = new Point(184, 29);
            CreateAccountLbl.Name = "CreateAccountLbl";
            CreateAccountLbl.Size = new Size(185, 31);
            CreateAccountLbl.TabIndex = 0;
            CreateAccountLbl.Text = "Create Account";
            // 
            // AllAccountsGroupbox
            // 
            AllAccountsGroupbox.Controls.Add(AccountsGrid);
            AllAccountsGroupbox.Controls.Add(AllAccountsHomeButton);
            AllAccountsGroupbox.Controls.Add(AllAccountsLbl);
            AllAccountsGroupbox.Location = new Point(12, 12);
            AllAccountsGroupbox.Margin = new Padding(2);
            AllAccountsGroupbox.Name = "AllAccountsGroupbox";
            AllAccountsGroupbox.Size = new Size(557, 457);
            AllAccountsGroupbox.TabIndex = 12;
            AllAccountsGroupbox.TabStop = false;
            AllAccountsGroupbox.Visible = false;
            // 
            // AccountsGrid
            // 
            AccountsGrid.AccessibleRole = AccessibleRole.None;
            AccountsGrid.AllowUserToAddRows = false;
            AccountsGrid.AllowUserToDeleteRows = false;
            AccountsGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            AccountsGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            AccountsGrid.ImeMode = ImeMode.NoControl;
            AccountsGrid.Location = new Point(6, 66);
            AccountsGrid.MultiSelect = false;
            AccountsGrid.Name = "AccountsGrid";
            AccountsGrid.ReadOnly = true;
            AccountsGrid.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            AccountsGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            AccountsGrid.Size = new Size(545, 385);
            AccountsGrid.TabIndex = 13;
            AccountsGrid.TabStop = false;
            AccountsGrid.CellClick += AccountsGrid_CellClick;
            // 
            // AllAccountsHomeButton
            // 
            AllAccountsHomeButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AllAccountsHomeButton.Location = new Point(6, 17);
            AllAccountsHomeButton.Name = "AllAccountsHomeButton";
            AllAccountsHomeButton.Size = new Size(81, 43);
            AllAccountsHomeButton.TabIndex = 4;
            AllAccountsHomeButton.Text = "Home";
            AllAccountsHomeButton.UseVisualStyleBackColor = true;
            AllAccountsHomeButton.Click += AllAccountsHomeButton_Click;
            // 
            // AllAccountsLbl
            // 
            AllAccountsLbl.AutoSize = true;
            AllAccountsLbl.Font = new Font("Sylfaen", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AllAccountsLbl.Location = new Point(184, 29);
            AllAccountsLbl.Name = "AllAccountsLbl";
            AllAccountsLbl.Size = new Size(155, 31);
            AllAccountsLbl.TabIndex = 0;
            AllAccountsLbl.Text = "All Accounts";
            // 
            // SearchAccountGroupBox
            // 
            SearchAccountGroupBox.Controls.Add(SearchEnterIDORNameLbl);
            SearchAccountGroupBox.Controls.Add(SearchAccountsGrid);
            SearchAccountGroupBox.Controls.Add(SearchStatusLbl);
            SearchAccountGroupBox.Controls.Add(SearchCustomerNameTextbox);
            SearchAccountGroupBox.Controls.Add(SearchBox);
            SearchAccountGroupBox.Controls.Add(SearchHomeButton);
            SearchAccountGroupBox.Controls.Add(SearchButton);
            SearchAccountGroupBox.Controls.Add(SearchAccountLbl);
            SearchAccountGroupBox.Location = new Point(12, 12);
            SearchAccountGroupBox.Name = "SearchAccountGroupBox";
            SearchAccountGroupBox.Size = new Size(557, 457);
            SearchAccountGroupBox.TabIndex = 12;
            SearchAccountGroupBox.TabStop = false;
            SearchAccountGroupBox.Visible = false;
            // 
            // SearchEnterIDORNameLbl
            // 
            SearchEnterIDORNameLbl.AutoSize = true;
            SearchEnterIDORNameLbl.Location = new Point(145, 61);
            SearchEnterIDORNameLbl.Name = "SearchEnterIDORNameLbl";
            SearchEnterIDORNameLbl.Size = new Size(243, 15);
            SearchEnterIDORNameLbl.TabIndex = 12;
            SearchEnterIDORNameLbl.Text = "Please enter Customer Name or Customer ID";
            // 
            // SearchAccountsGrid
            // 
            SearchAccountsGrid.AccessibleRole = AccessibleRole.None;
            SearchAccountsGrid.AllowUserToAddRows = false;
            SearchAccountsGrid.AllowUserToDeleteRows = false;
            SearchAccountsGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            SearchAccountsGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            SearchAccountsGrid.ImeMode = ImeMode.NoControl;
            SearchAccountsGrid.Location = new Point(6, 196);
            SearchAccountsGrid.MultiSelect = false;
            SearchAccountsGrid.Name = "SearchAccountsGrid";
            SearchAccountsGrid.ReadOnly = true;
            SearchAccountsGrid.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            SearchAccountsGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            SearchAccountsGrid.Size = new Size(545, 255);
            SearchAccountsGrid.TabIndex = 0;
            SearchAccountsGrid.TabStop = false;
            SearchAccountsGrid.CellClick += SearchAccount_CellClick;
            // 
            // SearchStatusLbl
            // 
            SearchStatusLbl.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            SearchStatusLbl.Location = new Point(0, 240);
            SearchStatusLbl.Name = "SearchStatusLbl";
            SearchStatusLbl.Size = new Size(551, 24);
            SearchStatusLbl.TabIndex = 11;
            SearchStatusLbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // SearchCustomerNameTextbox
            // 
            SearchCustomerNameTextbox.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            SearchCustomerNameTextbox.Location = new Point(288, 94);
            SearchCustomerNameTextbox.Name = "SearchCustomerNameTextbox";
            SearchCustomerNameTextbox.PlaceholderText = "Ex. John Smith / 1011";
            SearchCustomerNameTextbox.Size = new Size(188, 33);
            SearchCustomerNameTextbox.TabIndex = 6;
            // 
            // SearchBox
            // 
            SearchBox.AutoSize = true;
            SearchBox.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchBox.Location = new Point(80, 97);
            SearchBox.Name = "SearchBox";
            SearchBox.Size = new Size(212, 25);
            SearchBox.TabIndex = 5;
            SearchBox.Text = "Enter Name or ID . . . . .";
            // 
            // SearchHomeButton
            // 
            SearchHomeButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchHomeButton.Location = new Point(6, 17);
            SearchHomeButton.Name = "SearchHomeButton";
            SearchHomeButton.Size = new Size(81, 43);
            SearchHomeButton.TabIndex = 4;
            SearchHomeButton.Text = "Home";
            SearchHomeButton.UseVisualStyleBackColor = true;
            SearchHomeButton.Click += SearchHomeButton_Click;
            // 
            // SearchButton
            // 
            SearchButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchButton.Location = new Point(174, 138);
            SearchButton.Name = "SearchButton";
            SearchButton.Size = new Size(208, 43);
            SearchButton.TabIndex = 1;
            SearchButton.Text = "Search";
            SearchButton.UseVisualStyleBackColor = true;
            SearchButton.Click += SearchButton_Click;
            // 
            // SearchAccountLbl
            // 
            SearchAccountLbl.AutoSize = true;
            SearchAccountLbl.Font = new Font("Sylfaen", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchAccountLbl.Location = new Point(163, 29);
            SearchAccountLbl.Name = "SearchAccountLbl";
            SearchAccountLbl.Size = new Size(230, 31);
            SearchAccountLbl.TabIndex = 0;
            SearchAccountLbl.Text = "Search For Account";
            // 
            // TransactionsGroupBox
            // 
            TransactionsGroupBox.Controls.Add(TransferPageButton);
            TransactionsGroupBox.Controls.Add(WithdrawPageButton);
            TransactionsGroupBox.Controls.Add(DepositPageButton);
            TransactionsGroupBox.Controls.Add(TransactionHomeButton);
            TransactionsGroupBox.Location = new Point(12, 12);
            TransactionsGroupBox.Margin = new Padding(2);
            TransactionsGroupBox.Name = "TransactionsGroupBox";
            TransactionsGroupBox.Padding = new Padding(2);
            TransactionsGroupBox.Size = new Size(557, 457);
            TransactionsGroupBox.TabIndex = 13;
            TransactionsGroupBox.TabStop = false;
            TransactionsGroupBox.Visible = false;
            TransactionsGroupBox.Enter += TransactionsGroupBox_Enter;
            // 
            // TransferPageButton
            // 
            TransferPageButton.Location = new Point(353, 192);
            TransferPageButton.Margin = new Padding(2);
            TransferPageButton.Name = "TransferPageButton";
            TransferPageButton.Size = new Size(78, 46);
            TransferPageButton.TabIndex = 6;
            TransferPageButton.Text = "Transfer";
            TransferPageButton.UseVisualStyleBackColor = true;
            TransferPageButton.Click += TransferPageButton_Click;
            // 
            // WithdrawPageButton
            // 
            WithdrawPageButton.Location = new Point(230, 193);
            WithdrawPageButton.Margin = new Padding(2);
            WithdrawPageButton.Name = "WithdrawPageButton";
            WithdrawPageButton.Size = new Size(78, 46);
            WithdrawPageButton.TabIndex = 5;
            WithdrawPageButton.Text = "Withdraw";
            WithdrawPageButton.UseVisualStyleBackColor = true;
            WithdrawPageButton.Click += WithdrawPageButton_Click;
            // 
            // DepositPageButton
            // 
            DepositPageButton.Location = new Point(114, 193);
            DepositPageButton.Margin = new Padding(2);
            DepositPageButton.Name = "DepositPageButton";
            DepositPageButton.Size = new Size(78, 46);
            DepositPageButton.TabIndex = 4;
            DepositPageButton.Text = "Deposit";
            DepositPageButton.UseVisualStyleBackColor = true;
            DepositPageButton.Click += DepositPageButton_Click;
            // 
            // TransactionHomeButton
            // 
            TransactionHomeButton.Location = new Point(12, 18);
            TransactionHomeButton.Margin = new Padding(2);
            TransactionHomeButton.Name = "TransactionHomeButton";
            TransactionHomeButton.Size = new Size(78, 42);
            TransactionHomeButton.TabIndex = 3;
            TransactionHomeButton.Text = "Home";
            TransactionHomeButton.UseVisualStyleBackColor = true;
            TransactionHomeButton.Click += TransactionHomeButton_Click;
            // 
            // DepositGroupBox
            // 
            DepositGroupBox.Controls.Add(DepositNewBalance);
            DepositGroupBox.Controls.Add(DepositOldBalanceLabel);
            DepositGroupBox.Controls.Add(DepositUpdatedBalanceLabel);
            DepositGroupBox.Controls.Add(DepositPreviousBalanceLabel);
            DepositGroupBox.Controls.Add(DepositStatusLabel);
            DepositGroupBox.Controls.Add(DepositButton);
            DepositGroupBox.Controls.Add(DepositAmountTextBox);
            DepositGroupBox.Controls.Add(DepositAccountNumberTextBox);
            DepositGroupBox.Controls.Add(DepositAmountLabel);
            DepositGroupBox.Controls.Add(DepositAccountNumberLabel);
            DepositGroupBox.Controls.Add(DepositBackButton);
            DepositGroupBox.Location = new Point(12, 12);
            DepositGroupBox.Margin = new Padding(2);
            DepositGroupBox.Name = "DepositGroupBox";
            DepositGroupBox.Padding = new Padding(2);
            DepositGroupBox.Size = new Size(556, 452);
            DepositGroupBox.TabIndex = 14;
            DepositGroupBox.TabStop = false;
            DepositGroupBox.Visible = false;
            DepositGroupBox.Enter += DepositGroupBox_Enter;
            // 
            // DepositNewBalance
            // 
            DepositNewBalance.AutoSize = true;
            DepositNewBalance.Location = new Point(110, 314);
            DepositNewBalance.Margin = new Padding(2, 0, 2, 0);
            DepositNewBalance.Name = "DepositNewBalance";
            DepositNewBalance.Size = new Size(78, 15);
            DepositNewBalance.TabIndex = 10;
            DepositNewBalance.Text = "New balance:";
            // 
            // DepositOldBalanceLabel
            // 
            DepositOldBalanceLabel.AutoSize = true;
            DepositOldBalanceLabel.Location = new Point(114, 286);
            DepositOldBalanceLabel.Margin = new Padding(2, 0, 2, 0);
            DepositOldBalanceLabel.Name = "DepositOldBalanceLabel";
            DepositOldBalanceLabel.Size = new Size(73, 15);
            DepositOldBalanceLabel.TabIndex = 9;
            DepositOldBalanceLabel.Text = "Old balance:";
            // 
            // DepositUpdatedBalanceLabel
            // 
            DepositUpdatedBalanceLabel.AutoSize = true;
            DepositUpdatedBalanceLabel.Location = new Point(202, 314);
            DepositUpdatedBalanceLabel.Margin = new Padding(2, 0, 2, 0);
            DepositUpdatedBalanceLabel.Name = "DepositUpdatedBalanceLabel";
            DepositUpdatedBalanceLabel.Size = new Size(38, 15);
            DepositUpdatedBalanceLabel.TabIndex = 8;
            DepositUpdatedBalanceLabel.Text = "label5";
            // 
            // DepositPreviousBalanceLabel
            // 
            DepositPreviousBalanceLabel.AutoSize = true;
            DepositPreviousBalanceLabel.Location = new Point(202, 286);
            DepositPreviousBalanceLabel.Margin = new Padding(2, 0, 2, 0);
            DepositPreviousBalanceLabel.Name = "DepositPreviousBalanceLabel";
            DepositPreviousBalanceLabel.Size = new Size(38, 15);
            DepositPreviousBalanceLabel.TabIndex = 7;
            DepositPreviousBalanceLabel.Text = "label4";
            // 
            // DepositStatusLabel
            // 
            DepositStatusLabel.AutoSize = true;
            DepositStatusLabel.Location = new Point(202, 257);
            DepositStatusLabel.Margin = new Padding(2, 0, 2, 0);
            DepositStatusLabel.Name = "DepositStatusLabel";
            DepositStatusLabel.Size = new Size(38, 15);
            DepositStatusLabel.TabIndex = 6;
            DepositStatusLabel.Text = "label3";
            // 
            // DepositButton
            // 
            DepositButton.Location = new Point(120, 203);
            DepositButton.Margin = new Padding(2);
            DepositButton.Name = "DepositButton";
            DepositButton.Size = new Size(78, 20);
            DepositButton.TabIndex = 5;
            DepositButton.Text = "Deposit";
            DepositButton.UseVisualStyleBackColor = true;
            DepositButton.Click += DepositButton_Click;
            // 
            // DepositAmountTextBox
            // 
            DepositAmountTextBox.Location = new Point(220, 155);
            DepositAmountTextBox.Margin = new Padding(2);
            DepositAmountTextBox.Name = "DepositAmountTextBox";
            DepositAmountTextBox.Size = new Size(106, 23);
            DepositAmountTextBox.TabIndex = 4;
            // 
            // DepositAccountNumberTextBox
            // 
            DepositAccountNumberTextBox.Location = new Point(220, 124);
            DepositAccountNumberTextBox.Margin = new Padding(2);
            DepositAccountNumberTextBox.Name = "DepositAccountNumberTextBox";
            DepositAccountNumberTextBox.Size = new Size(106, 23);
            DepositAccountNumberTextBox.TabIndex = 3;
            // 
            // DepositAmountLabel
            // 
            DepositAmountLabel.AutoSize = true;
            DepositAmountLabel.Location = new Point(67, 159);
            DepositAmountLabel.Margin = new Padding(2, 0, 2, 0);
            DepositAmountLabel.Name = "DepositAmountLabel";
            DepositAmountLabel.Size = new Size(124, 15);
            DepositAmountLabel.TabIndex = 2;
            DepositAmountLabel.Text = "Enter deposit amount:";
            // 
            // DepositAccountNumberLabel
            // 
            DepositAccountNumberLabel.AutoSize = true;
            DepositAccountNumberLabel.Location = new Point(66, 126);
            DepositAccountNumberLabel.Margin = new Padding(2, 0, 2, 0);
            DepositAccountNumberLabel.Name = "DepositAccountNumberLabel";
            DepositAccountNumberLabel.Size = new Size(128, 15);
            DepositAccountNumberLabel.TabIndex = 1;
            DepositAccountNumberLabel.Text = "Enter account number:";
            // 
            // DepositBackButton
            // 
            DepositBackButton.Location = new Point(25, 18);
            DepositBackButton.Margin = new Padding(2);
            DepositBackButton.Name = "DepositBackButton";
            DepositBackButton.Size = new Size(78, 20);
            DepositBackButton.TabIndex = 0;
            DepositBackButton.Text = "Back";
            DepositBackButton.UseVisualStyleBackColor = true;
            DepositBackButton.Click += DepositBackButton_Click;
            // 
            // WithdrawGroupBox
            // 
            WithdrawGroupBox.Controls.Add(WithdrawUpdatedBalance);
            WithdrawGroupBox.Controls.Add(WithdrawPreviousBalance);
            WithdrawGroupBox.Controls.Add(WithdrawStatusLabel);
            WithdrawGroupBox.Controls.Add(WithdrawNewBalanceLabel);
            WithdrawGroupBox.Controls.Add(WithdrawOldBalanceLabel);
            WithdrawGroupBox.Controls.Add(WithdrawAmountTextBox);
            WithdrawGroupBox.Controls.Add(WithdrawAccountNumberTextBox);
            WithdrawGroupBox.Controls.Add(WithdrawAmountLabel);
            WithdrawGroupBox.Controls.Add(WithdrawAccountNumberLabel);
            WithdrawGroupBox.Controls.Add(WithdrawButton);
            WithdrawGroupBox.Controls.Add(WithdrawBackButton);
            WithdrawGroupBox.Location = new Point(12, 12);
            WithdrawGroupBox.Margin = new Padding(2);
            WithdrawGroupBox.Name = "WithdrawGroupBox";
            WithdrawGroupBox.Padding = new Padding(2);
            WithdrawGroupBox.Size = new Size(556, 452);
            WithdrawGroupBox.TabIndex = 15;
            WithdrawGroupBox.TabStop = false;
            WithdrawGroupBox.Visible = false;
            WithdrawGroupBox.Enter += WithdrawGroupBox_Enter;
            // 
            // WithdrawUpdatedBalance
            // 
            WithdrawUpdatedBalance.AutoSize = true;
            WithdrawUpdatedBalance.Location = new Point(181, 299);
            WithdrawUpdatedBalance.Margin = new Padding(2, 0, 2, 0);
            WithdrawUpdatedBalance.Name = "WithdrawUpdatedBalance";
            WithdrawUpdatedBalance.Size = new Size(38, 15);
            WithdrawUpdatedBalance.TabIndex = 10;
            WithdrawUpdatedBalance.Text = "label7";
            // 
            // WithdrawPreviousBalance
            // 
            WithdrawPreviousBalance.AutoSize = true;
            WithdrawPreviousBalance.Location = new Point(181, 266);
            WithdrawPreviousBalance.Margin = new Padding(2, 0, 2, 0);
            WithdrawPreviousBalance.Name = "WithdrawPreviousBalance";
            WithdrawPreviousBalance.Size = new Size(38, 15);
            WithdrawPreviousBalance.TabIndex = 9;
            WithdrawPreviousBalance.Text = "label6";
            // 
            // WithdrawStatusLabel
            // 
            WithdrawStatusLabel.AutoSize = true;
            WithdrawStatusLabel.Location = new Point(181, 237);
            WithdrawStatusLabel.Margin = new Padding(2, 0, 2, 0);
            WithdrawStatusLabel.Name = "WithdrawStatusLabel";
            WithdrawStatusLabel.Size = new Size(38, 15);
            WithdrawStatusLabel.TabIndex = 8;
            WithdrawStatusLabel.Text = "label5";
            // 
            // WithdrawNewBalanceLabel
            // 
            WithdrawNewBalanceLabel.AutoSize = true;
            WithdrawNewBalanceLabel.Location = new Point(89, 299);
            WithdrawNewBalanceLabel.Margin = new Padding(2, 0, 2, 0);
            WithdrawNewBalanceLabel.Name = "WithdrawNewBalanceLabel";
            WithdrawNewBalanceLabel.Size = new Size(78, 15);
            WithdrawNewBalanceLabel.TabIndex = 7;
            WithdrawNewBalanceLabel.Text = "New Balance:";
            // 
            // WithdrawOldBalanceLabel
            // 
            WithdrawOldBalanceLabel.AutoSize = true;
            WithdrawOldBalanceLabel.Location = new Point(93, 266);
            WithdrawOldBalanceLabel.Margin = new Padding(2, 0, 2, 0);
            WithdrawOldBalanceLabel.Name = "WithdrawOldBalanceLabel";
            WithdrawOldBalanceLabel.Size = new Size(73, 15);
            WithdrawOldBalanceLabel.TabIndex = 6;
            WithdrawOldBalanceLabel.Text = "Old Balance:";
            // 
            // WithdrawAmountTextBox
            // 
            WithdrawAmountTextBox.Location = new Point(204, 135);
            WithdrawAmountTextBox.Margin = new Padding(2);
            WithdrawAmountTextBox.Name = "WithdrawAmountTextBox";
            WithdrawAmountTextBox.Size = new Size(106, 23);
            WithdrawAmountTextBox.TabIndex = 5;
            // 
            // WithdrawAccountNumberTextBox
            // 
            WithdrawAccountNumberTextBox.Location = new Point(202, 95);
            WithdrawAccountNumberTextBox.Margin = new Padding(2);
            WithdrawAccountNumberTextBox.Name = "WithdrawAccountNumberTextBox";
            WithdrawAccountNumberTextBox.Size = new Size(106, 23);
            WithdrawAccountNumberTextBox.TabIndex = 4;
            // 
            // WithdrawAmountLabel
            // 
            WithdrawAmountLabel.AutoSize = true;
            WithdrawAmountLabel.Location = new Point(37, 137);
            WithdrawAmountLabel.Margin = new Padding(2, 0, 2, 0);
            WithdrawAmountLabel.Name = "WithdrawAmountLabel";
            WithdrawAmountLabel.Size = new Size(134, 15);
            WithdrawAmountLabel.TabIndex = 3;
            WithdrawAmountLabel.Text = "Enter withdraw amount:";
            // 
            // WithdrawAccountNumberLabel
            // 
            WithdrawAccountNumberLabel.AutoSize = true;
            WithdrawAccountNumberLabel.Location = new Point(43, 97);
            WithdrawAccountNumberLabel.Margin = new Padding(2, 0, 2, 0);
            WithdrawAccountNumberLabel.Name = "WithdrawAccountNumberLabel";
            WithdrawAccountNumberLabel.Size = new Size(128, 15);
            WithdrawAccountNumberLabel.TabIndex = 2;
            WithdrawAccountNumberLabel.Text = "Enter account number:";
            // 
            // WithdrawButton
            // 
            WithdrawButton.Location = new Point(120, 193);
            WithdrawButton.Margin = new Padding(2);
            WithdrawButton.Name = "WithdrawButton";
            WithdrawButton.Size = new Size(78, 20);
            WithdrawButton.TabIndex = 1;
            WithdrawButton.Text = "Withdraw";
            WithdrawButton.UseVisualStyleBackColor = true;
            WithdrawButton.Click += WithdrawButton_Click;
            // 
            // WithdrawBackButton
            // 
            WithdrawBackButton.Location = new Point(8, 7);
            WithdrawBackButton.Margin = new Padding(2);
            WithdrawBackButton.Name = "WithdrawBackButton";
            WithdrawBackButton.Size = new Size(78, 20);
            WithdrawBackButton.TabIndex = 0;
            WithdrawBackButton.Text = "Back";
            WithdrawBackButton.UseVisualStyleBackColor = true;
            WithdrawBackButton.Click += WithdrawBackButton_Click;
            // 
            // TransferGroupBox
            // 
            TransferGroupBox.Controls.Add(TransferReceiverUpdatedBalance);
            TransferGroupBox.Controls.Add(TransferReceiverNewBalance);
            TransferGroupBox.Controls.Add(TransferReceiverPreviousBalance);
            TransferGroupBox.Controls.Add(TransferReceiverOldBalance);
            TransferGroupBox.Controls.Add(TransferSenderUpdatedBalance);
            TransferGroupBox.Controls.Add(TransferSenderNewBalance);
            TransferGroupBox.Controls.Add(TransferSenderPreviousBalance);
            TransferGroupBox.Controls.Add(TransferSenderOldBalanceLabel);
            TransferGroupBox.Controls.Add(TransferStatusLabel);
            TransferGroupBox.Controls.Add(TransferButton);
            TransferGroupBox.Controls.Add(TransferAmountTextBox);
            TransferGroupBox.Controls.Add(TransferAmountLabel);
            TransferGroupBox.Controls.Add(TransferReceiverAccountTextBox);
            TransferGroupBox.Controls.Add(TransferReceiverAccountLabel);
            TransferGroupBox.Controls.Add(TransferSenderAccountTextBox);
            TransferGroupBox.Controls.Add(TransferSenderAccountLabel);
            TransferGroupBox.Controls.Add(TransferBackButton);
            TransferGroupBox.Location = new Point(12, 12);
            TransferGroupBox.Margin = new Padding(2);
            TransferGroupBox.Name = "TransferGroupBox";
            TransferGroupBox.Padding = new Padding(2);
            TransferGroupBox.Size = new Size(557, 457);
            TransferGroupBox.TabIndex = 15;
            TransferGroupBox.TabStop = false;
            TransferGroupBox.Visible = false;
            TransferGroupBox.Enter += TransferGroupBox_Enter;
            // 
            // TransferReceiverUpdatedBalance
            // 
            TransferReceiverUpdatedBalance.AutoSize = true;
            TransferReceiverUpdatedBalance.Location = new Point(211, 351);
            TransferReceiverUpdatedBalance.Margin = new Padding(2, 0, 2, 0);
            TransferReceiverUpdatedBalance.Name = "TransferReceiverUpdatedBalance";
            TransferReceiverUpdatedBalance.Size = new Size(38, 15);
            TransferReceiverUpdatedBalance.TabIndex = 16;
            TransferReceiverUpdatedBalance.Text = "label1";
            // 
            // TransferReceiverNewBalance
            // 
            TransferReceiverNewBalance.AutoSize = true;
            TransferReceiverNewBalance.Location = new Point(59, 351);
            TransferReceiverNewBalance.Margin = new Padding(2, 0, 2, 0);
            TransferReceiverNewBalance.Name = "TransferReceiverNewBalance";
            TransferReceiverNewBalance.Size = new Size(123, 15);
            TransferReceiverNewBalance.TabIndex = 15;
            TransferReceiverNewBalance.Text = "Receiver new balance:";
            // 
            // TransferReceiverPreviousBalance
            // 
            TransferReceiverPreviousBalance.AutoSize = true;
            TransferReceiverPreviousBalance.Location = new Point(211, 324);
            TransferReceiverPreviousBalance.Margin = new Padding(2, 0, 2, 0);
            TransferReceiverPreviousBalance.Name = "TransferReceiverPreviousBalance";
            TransferReceiverPreviousBalance.Size = new Size(38, 15);
            TransferReceiverPreviousBalance.TabIndex = 14;
            TransferReceiverPreviousBalance.Text = "label1";
            // 
            // TransferReceiverOldBalance
            // 
            TransferReceiverOldBalance.AutoSize = true;
            TransferReceiverOldBalance.Location = new Point(67, 323);
            TransferReceiverOldBalance.Margin = new Padding(2, 0, 2, 0);
            TransferReceiverOldBalance.Name = "TransferReceiverOldBalance";
            TransferReceiverOldBalance.Size = new Size(118, 15);
            TransferReceiverOldBalance.TabIndex = 13;
            TransferReceiverOldBalance.Text = "Receiver old balance:";
            // 
            // TransferSenderUpdatedBalance
            // 
            TransferSenderUpdatedBalance.AutoSize = true;
            TransferSenderUpdatedBalance.Location = new Point(211, 293);
            TransferSenderUpdatedBalance.Margin = new Padding(2, 0, 2, 0);
            TransferSenderUpdatedBalance.Name = "TransferSenderUpdatedBalance";
            TransferSenderUpdatedBalance.Size = new Size(38, 15);
            TransferSenderUpdatedBalance.TabIndex = 12;
            TransferSenderUpdatedBalance.Text = "label1";
            // 
            // TransferSenderNewBalance
            // 
            TransferSenderNewBalance.AutoSize = true;
            TransferSenderNewBalance.Location = new Point(69, 293);
            TransferSenderNewBalance.Margin = new Padding(2, 0, 2, 0);
            TransferSenderNewBalance.Name = "TransferSenderNewBalance";
            TransferSenderNewBalance.Size = new Size(115, 15);
            TransferSenderNewBalance.TabIndex = 11;
            TransferSenderNewBalance.Text = "Sender new balance:";
            // 
            // TransferSenderPreviousBalance
            // 
            TransferSenderPreviousBalance.AutoSize = true;
            TransferSenderPreviousBalance.Location = new Point(211, 266);
            TransferSenderPreviousBalance.Margin = new Padding(2, 0, 2, 0);
            TransferSenderPreviousBalance.Name = "TransferSenderPreviousBalance";
            TransferSenderPreviousBalance.Size = new Size(38, 15);
            TransferSenderPreviousBalance.TabIndex = 10;
            TransferSenderPreviousBalance.Text = "label1";
            // 
            // TransferSenderOldBalanceLabel
            // 
            TransferSenderOldBalanceLabel.AutoSize = true;
            TransferSenderOldBalanceLabel.Location = new Point(74, 266);
            TransferSenderOldBalanceLabel.Margin = new Padding(2, 0, 2, 0);
            TransferSenderOldBalanceLabel.Name = "TransferSenderOldBalanceLabel";
            TransferSenderOldBalanceLabel.Size = new Size(110, 15);
            TransferSenderOldBalanceLabel.TabIndex = 9;
            TransferSenderOldBalanceLabel.Text = "Sender old balance:";
            // 
            // TransferStatusLabel
            // 
            TransferStatusLabel.AutoSize = true;
            TransferStatusLabel.Location = new Point(211, 238);
            TransferStatusLabel.Margin = new Padding(2, 0, 2, 0);
            TransferStatusLabel.Name = "TransferStatusLabel";
            TransferStatusLabel.Size = new Size(38, 15);
            TransferStatusLabel.TabIndex = 8;
            TransferStatusLabel.Text = "label1";
            // 
            // TransferButton
            // 
            TransferButton.Location = new Point(131, 204);
            TransferButton.Margin = new Padding(2);
            TransferButton.Name = "TransferButton";
            TransferButton.Size = new Size(78, 20);
            TransferButton.TabIndex = 7;
            TransferButton.Text = "Transfer";
            TransferButton.UseVisualStyleBackColor = true;
            TransferButton.Click += TransferButton_Click;
            // 
            // TransferAmountTextBox
            // 
            TransferAmountTextBox.Location = new Point(238, 163);
            TransferAmountTextBox.Margin = new Padding(2);
            TransferAmountTextBox.Name = "TransferAmountTextBox";
            TransferAmountTextBox.Size = new Size(106, 23);
            TransferAmountTextBox.TabIndex = 6;
            // 
            // TransferAmountLabel
            // 
            TransferAmountLabel.AutoSize = true;
            TransferAmountLabel.Location = new Point(106, 160);
            TransferAmountLabel.Margin = new Padding(2, 0, 2, 0);
            TransferAmountLabel.Name = "TransferAmountLabel";
            TransferAmountLabel.Size = new Size(99, 15);
            TransferAmountLabel.TabIndex = 5;
            TransferAmountLabel.Text = "Transfer Amount:";
            // 
            // TransferReceiverAccountTextBox
            // 
            TransferReceiverAccountTextBox.Location = new Point(238, 128);
            TransferReceiverAccountTextBox.Margin = new Padding(2);
            TransferReceiverAccountTextBox.Name = "TransferReceiverAccountTextBox";
            TransferReceiverAccountTextBox.Size = new Size(106, 23);
            TransferReceiverAccountTextBox.TabIndex = 4;
            // 
            // TransferReceiverAccountLabel
            // 
            TransferReceiverAccountLabel.AutoSize = true;
            TransferReceiverAccountLabel.Location = new Point(51, 127);
            TransferReceiverAccountLabel.Margin = new Padding(2, 0, 2, 0);
            TransferReceiverAccountLabel.Name = "TransferReceiverAccountLabel";
            TransferReceiverAccountLabel.Size = new Size(153, 15);
            TransferReceiverAccountLabel.TabIndex = 3;
            TransferReceiverAccountLabel.Text = "Receiver's account number:";
            // 
            // TransferSenderAccountTextBox
            // 
            TransferSenderAccountTextBox.Location = new Point(238, 92);
            TransferSenderAccountTextBox.Margin = new Padding(2);
            TransferSenderAccountTextBox.Name = "TransferSenderAccountTextBox";
            TransferSenderAccountTextBox.Size = new Size(106, 23);
            TransferSenderAccountTextBox.TabIndex = 2;
            // 
            // TransferSenderAccountLabel
            // 
            TransferSenderAccountLabel.AutoSize = true;
            TransferSenderAccountLabel.Location = new Point(57, 94);
            TransferSenderAccountLabel.Margin = new Padding(2, 0, 2, 0);
            TransferSenderAccountLabel.Name = "TransferSenderAccountLabel";
            TransferSenderAccountLabel.Size = new Size(145, 15);
            TransferSenderAccountLabel.TabIndex = 1;
            TransferSenderAccountLabel.Text = "Sender's account number:";
            // 
            // TransferBackButton
            // 
            TransferBackButton.Location = new Point(9, 18);
            TransferBackButton.Margin = new Padding(2);
            TransferBackButton.Name = "TransferBackButton";
            TransferBackButton.Size = new Size(78, 29);
            TransferBackButton.TabIndex = 0;
            TransferBackButton.Text = "Back";
            TransferBackButton.UseVisualStyleBackColor = true;
            TransferBackButton.Click += TransferBackButton_Click;
            // 
            // FullAccountDetails
            // 
            FullAccountDetails.Controls.Add(AccDetailsAccNum);
            FullAccountDetails.Controls.Add(AccDetailsDateCreated);
            FullAccountDetails.Controls.Add(AccDetailsMinBal);
            FullAccountDetails.Controls.Add(AccDetailsCurrentBal);
            FullAccountDetails.Controls.Add(AccDetailsCustomerName);
            FullAccountDetails.Controls.Add(label6);
            FullAccountDetails.Controls.Add(AccDetailsTransactionGridBox);
            FullAccountDetails.Controls.Add(label7);
            FullAccountDetails.Controls.Add(label8);
            FullAccountDetails.Controls.Add(label9);
            FullAccountDetails.Controls.Add(label10);
            FullAccountDetails.Controls.Add(AccDetailsBackButton);
            FullAccountDetails.Controls.Add(AccountDetailsLbl);
            FullAccountDetails.Location = new Point(12, 12);
            FullAccountDetails.Name = "FullAccountDetails";
            FullAccountDetails.Size = new Size(557, 457);
            FullAccountDetails.TabIndex = 13;
            FullAccountDetails.TabStop = false;
            FullAccountDetails.Visible = false;
            // 
            // AccDetailsAccNum
            // 
            AccDetailsAccNum.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AccDetailsAccNum.Location = new Point(165, 73);
            AccDetailsAccNum.Name = "AccDetailsAccNum";
            AccDetailsAccNum.Size = new Size(388, 20);
            AccDetailsAccNum.TabIndex = 30;
            // 
            // AccDetailsDateCreated
            // 
            AccDetailsDateCreated.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AccDetailsDateCreated.Location = new Point(165, 173);
            AccDetailsDateCreated.Name = "AccDetailsDateCreated";
            AccDetailsDateCreated.Size = new Size(388, 20);
            AccDetailsDateCreated.TabIndex = 29;
            // 
            // AccDetailsMinBal
            // 
            AccDetailsMinBal.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AccDetailsMinBal.Location = new Point(165, 148);
            AccDetailsMinBal.Name = "AccDetailsMinBal";
            AccDetailsMinBal.Size = new Size(388, 20);
            AccDetailsMinBal.TabIndex = 28;
            // 
            // AccDetailsCurrentBal
            // 
            AccDetailsCurrentBal.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AccDetailsCurrentBal.Location = new Point(165, 123);
            AccDetailsCurrentBal.Name = "AccDetailsCurrentBal";
            AccDetailsCurrentBal.Size = new Size(388, 20);
            AccDetailsCurrentBal.TabIndex = 27;
            // 
            // AccDetailsCustomerName
            // 
            AccDetailsCustomerName.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AccDetailsCustomerName.Location = new Point(165, 99);
            AccDetailsCustomerName.Name = "AccDetailsCustomerName";
            AccDetailsCustomerName.Size = new Size(388, 20);
            AccDetailsCustomerName.TabIndex = 26;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            label6.Location = new Point(8, 73);
            label6.Name = "label6";
            label6.Size = new Size(158, 20);
            label6.TabIndex = 25;
            label6.Text = "Account Number . . . .";
            // 
            // AccDetailsTransactionGridBox
            // 
            AccDetailsTransactionGridBox.AccessibleRole = AccessibleRole.None;
            AccDetailsTransactionGridBox.AllowUserToAddRows = false;
            AccDetailsTransactionGridBox.AllowUserToDeleteRows = false;
            AccDetailsTransactionGridBox.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            AccDetailsTransactionGridBox.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            AccDetailsTransactionGridBox.ImeMode = ImeMode.NoControl;
            AccDetailsTransactionGridBox.Location = new Point(8, 199);
            AccDetailsTransactionGridBox.MultiSelect = false;
            AccDetailsTransactionGridBox.Name = "AccDetailsTransactionGridBox";
            AccDetailsTransactionGridBox.ReadOnly = true;
            AccDetailsTransactionGridBox.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            AccDetailsTransactionGridBox.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            AccDetailsTransactionGridBox.Size = new Size(545, 249);
            AccDetailsTransactionGridBox.TabIndex = 24;
            AccDetailsTransactionGridBox.TabStop = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            label7.Location = new Point(8, 173);
            label7.Name = "label7";
            label7.Size = new Size(158, 20);
            label7.TabIndex = 23;
            label7.Text = "Date Created  . . . . . . .";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            label8.Location = new Point(8, 148);
            label8.Name = "label8";
            label8.Size = new Size(160, 20);
            label8.TabIndex = 22;
            label8.Text = "Minimum Balance  . . .";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            label9.Location = new Point(8, 123);
            label9.Name = "label9";
            label9.Size = new Size(158, 20);
            label9.TabIndex = 21;
            label9.Text = "Current Balance . . . . .";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            label10.Location = new Point(8, 98);
            label10.Name = "label10";
            label10.Size = new Size(159, 20);
            label10.TabIndex = 20;
            label10.Text = "Customer Name . . . . .";
            // 
            // AccDetailsBackButton
            // 
            AccDetailsBackButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AccDetailsBackButton.Location = new Point(6, 17);
            AccDetailsBackButton.Name = "AccDetailsBackButton";
            AccDetailsBackButton.Size = new Size(81, 43);
            AccDetailsBackButton.TabIndex = 4;
            AccDetailsBackButton.Text = "Home";
            AccDetailsBackButton.UseVisualStyleBackColor = true;
            AccDetailsBackButton.Click += FullAccountDetailsHomeButton_Click;
            // 
            // AccountDetailsLbl
            // 
            AccountDetailsLbl.AutoSize = true;
            AccountDetailsLbl.Font = new Font("Sylfaen", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AccountDetailsLbl.Location = new Point(163, 29);
            AccountDetailsLbl.Name = "AccountDetailsLbl";
            AccountDetailsLbl.Size = new Size(188, 31);
            AccountDetailsLbl.TabIndex = 0;
            AccountDetailsLbl.Text = "Account Details";
            // 
            // MainPage
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(581, 481);
            Controls.Add(FullAccountDetails);
            Controls.Add(SearchAccountGroupBox);
            Controls.Add(HomeGroupBox);
            Controls.Add(AllAccountsGroupbox);
            Controls.Add(TransactionsGroupBox);
            Controls.Add(TransferGroupBox);
            Controls.Add(DepositGroupBox);
            Controls.Add(WithdrawGroupBox);
            Controls.Add(CreateAccountGroupBox);
            Name = "MainPage";
            Text = "ATM Banking";
            FormClosing += MainPage_Closing;
            Load += MainPage_Load;
            HomeGroupBox.ResumeLayout(false);
            HomeGroupBox.PerformLayout();
            CreateAccountGroupBox.ResumeLayout(false);
            CreateAccountGroupBox.PerformLayout();
            AllAccountsGroupbox.ResumeLayout(false);
            AllAccountsGroupbox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)AccountsGrid).EndInit();
            SearchAccountGroupBox.ResumeLayout(false);
            SearchAccountGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)SearchAccountsGrid).EndInit();
            TransactionsGroupBox.ResumeLayout(false);
            DepositGroupBox.ResumeLayout(false);
            DepositGroupBox.PerformLayout();
            WithdrawGroupBox.ResumeLayout(false);
            WithdrawGroupBox.PerformLayout();
            TransferGroupBox.ResumeLayout(false);
            TransferGroupBox.PerformLayout();
            FullAccountDetails.ResumeLayout(false);
            FullAccountDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)AccDetailsTransactionGridBox).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label WelcomeLbl;
        private GroupBox HomeGroupBox;
        private Button CreateAccountPageButton;
        private Button ViewAllAccountsPageButton;
        private Button SearchAccountPageButton;
        private GroupBox CreateAccountGroupBox;
        private Button CreateAccountButton;
        private Label CreateAccountLbl;
        private Button CreateHomeButton;
        private TextBox CreateMinimumBalanceTextBox;
        private Label CreateMinimumBalanceLbl;
        private TextBox CreateInitialDepositTextBox;
        private Label CreateInitialDepositLbl;
        private TextBox CreateCustomerNameTextBox;
        private Label CreateCustomerNameLbl;
        private Label CreateStatusLbl;
        private GroupBox SearchAccountGroupBox;
        private Label SearchStatusLbl;
        private TextBox SearchCustomerIDTextbox;
        private Label SearchWithIDLbl;
        private TextBox SearchCustomerNameTextbox;
        private Label SearchBox;
        private Button SearchHomeButton;
        private Button SearchButton;
        private Label SearchAccountLbl;
        private Label SearchEnterIDORNameLbl;
        private GroupBox AllAccountsGroupbox;
        private Button AllAccountsHomeButton;
        private Label AllAccountsLbl;
        private DataGridView AccountsGrid;
        private DataGridView SearchAccountsGrid;
        private GroupBox TransactionsGroupBox;
        private Button TransactionsPageButton;
        private Button TransactionHomeButton;
        private Button TransferPageButton;
        private Button WithdrawPageButton;
        private Button DepositPageButton;
        private GroupBox DepositGroupBox;
        private GroupBox WithdrawGroupBox;
        private GroupBox TransferGroupBox;
        private Button DepositBackButton;
        private Button WithdrawBackButton;
        private Button TransferBackButton;
        private Label DepositUpdatedBalanceLabel;
        private Label DepositPreviousBalanceLabel;
        private Label DepositStatusLabel;
        private Button DepositButton;
        private TextBox DepositAmountTextBox;
        private TextBox DepositAccountNumberTextBox;
        private Label DepositAmountLabel;
        private Label DepositAccountNumberLabel;
        private Label DepositNewBalance;
        private Label DepositOldBalanceLabel;
        private Label WithdrawUpdatedBalance;
        private Label WithdrawPreviousBalance;
        private Label WithdrawStatusLabel;
        private Label WithdrawNewBalanceLabel;
        private Label WithdrawOldBalanceLabel;
        private TextBox WithdrawAmountTextBox;
        private TextBox WithdrawAccountNumberTextBox;
        private Label WithdrawAmountLabel;
        private Label WithdrawAccountNumberLabel;
        private Button WithdrawButton;
        private Label TransferSenderAccountLabel;
        private TextBox TransferReceiverAccountTextBox;
        private Label TransferReceiverAccountLabel;
        private TextBox TransferSenderAccountTextBox;
        private TextBox TransferAmountTextBox;
        private Label TransferAmountLabel;
        private Button TransferButton;
        private Label TransferSenderOldBalanceLabel;
        private Label TransferStatusLabel;
        private Label TransferSenderNewBalance;
        private Label TransferSenderPreviousBalance;
        private Label TransferReceiverOldBalance;
        private Label TransferSenderUpdatedBalance;
        private Label TransferReceiverNewBalance;
        private Label TransferReceiverPreviousBalance;
        private Label TransferReceiverUpdatedBalance;
        private GroupBox FullAccountDetails;
        private DataGridView transactionGridBox;
        private Button AccDetailsBackButton;
        private Label AccountDetailsLbl;
        private Label AccDetailsAccNum;
        private Label AccDetailsDateCreated;
        private Label AccDetailsMinBal;
        private Label AccDetailsCurrentBal;
        private Label AccDetailsCustomerName;
        private Label label6;
        private DataGridView AccDetailsTransactionGridBox;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
    }
}
