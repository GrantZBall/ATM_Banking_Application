﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountManagement
{
    public class Withdraw
    {
        private AccountManager accountManager;

        public Withdraw(AccountManager accountManager)
        {
            this.accountManager = accountManager;
        }

        public bool ProcessWithdraw(string accountNumber, decimal amount)
        {
            // Find the account
            List<Account> matches = accountManager.FindAccount("", accountNumber, false, false);

            // Check if account exists
            if (matches.Count == 0)
            {
                return false;
            }

            // Get the account
            Account account = matches[0];

            // Process withdraw
            bool success = account.Withdraw(amount);

            // Save changes
            if (success)
            {
                accountManager.SaveAccountsToJson();
            }

            return success;
        }
    }
}
