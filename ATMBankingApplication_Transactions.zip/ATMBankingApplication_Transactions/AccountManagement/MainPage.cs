namespace AccountManagement
{
    public partial class MainPage : Form
    {
        // initialize accountManager and transactions
        AccountManager AccountManager;
        Deposit deposit;
        Withdraw withdraw;
        Transfer transfer;
        public MainPage()
        {
            InitializeComponent();
        }

        private void MainPage_Load(object sender, EventArgs e)
        {
            // fill the blank account manager and set home groupbox as visible
            AccountManager = new AccountManager();
            AccountManager.LoadAccountsFromJson();
            deposit = new Deposit(AccountManager);
            withdraw = new Withdraw(AccountManager);
            transfer = new Transfer(AccountManager);
            HomeGroupBox.Visible = true;
        }

        // function to refresh account list on "view all accounts" section
        private void RefreshAllAccountList(List<Account> accountList = null)
        {
            // use provided source for list or if no list, use Get all accounts function
            List<Account> source = accountList ?? AccountManager.GetAllAccounts();

            AccountsGrid.DataSource = null;
            AccountsGrid.DataSource = source;

            // Set column Balance and minimum balance to "c" = currency
            if (AccountsGrid.Columns["Balance"] != null)
                AccountsGrid.Columns["Balance"].DefaultCellStyle.Format = "c";
            if (AccountsGrid.Columns["MinimumBalance"] != null)
                AccountsGrid.Columns["MinimumBalance"].DefaultCellStyle.Format = "c";
        }

        // function to refresh account list on "search account" section
        private void RefreshSearchAccountList(List<Account> accountList = null)
        {
            // use provided source for list
            List<Account> source = accountList;

            SearchAccountsGrid.DataSource = null;
            SearchAccountsGrid.DataSource = source;

            // Set column Balance and minimum balance to "c" = currency
            if (SearchAccountsGrid.Columns["Balance"] != null)
                SearchAccountsGrid.Columns["Balance"].DefaultCellStyle.Format = "c";
            if (SearchAccountsGrid.Columns["Minimum Balance"] != null)
                SearchAccountsGrid.Columns["Minimum Balance"].DefaultCellStyle.Format = "c";
        }

        // All buttons to load each page -------------------------------------------------------------------------------------
        private void CreateAccountPageButton_Click(object sender, EventArgs e)
        {
            // Set create page visible and home as not visible
            HomeGroupBox.Visible = false;
            CreateAccountGroupBox.Visible = true;

            // make textboxes empty
            CreateCustomerNameTextBox.Text = string.Empty;
            CreateInitialDepositTextBox.Text = string.Empty;
            CreateMinimumBalanceTextBox.Text = string.Empty;
            CreateStatusLbl.Text = string.Empty;
        }

        private void SearchAccountPageButton_Click(object sender, EventArgs e)
        {
            // Set search page visible and home as not visible
            HomeGroupBox.Visible = false;
            SearchAccountGroupBox.Visible = true;
            RefreshSearchAccountList();

            // make textboxes empty
            SearchStatusLbl.Text = string.Empty;
            SearchCustomerIDTextbox.Text = string.Empty;
            SearchCustomerNameTextbox.Text = string.Empty;
        }
        private void ViewAllAccountsPageButton_Click(object sender, EventArgs e)
        {
            // Set view all accounts page visible and home as not visible
            HomeGroupBox.Visible = false;
            AllAccountsGroupbox.Visible = true;
            RefreshAllAccountList();

            // make textboxes empty
            AllAccountsCurrentCustomerIDLbl.Text = string.Empty;
            AllAccountsCurrentCustomerNameLbl.Text = string.Empty;
            AllAccountsCurrentCustomerBalanceLbl.Text = string.Empty;
            AllAccountsCurrentCustomerMinimumBalanceLbl.Text = string.Empty;
            AllAccountsCurrentCustomerCreatedLbl.Text = string.Empty;
        }

        // All Home Buttons to return to home page ------------------------------------------------------------------
        private void CreateHomeButton_Click(object sender, EventArgs e)
        {
            // Set home as visible and create to invisible
            HomeGroupBox.Visible = true;
            CreateAccountGroupBox.Visible = false;
        }

        private void SearchHomeButton_Click(object sender, EventArgs e)
        {
            // Set home as visible and search to invisible
            HomeGroupBox.Visible = true;
            SearchAccountGroupBox.Visible = false;
        }

        private void AllAccountsHomeButton_Click(object sender, EventArgs e)
        {
            // Set home as visible and All accounts to invisible
            HomeGroupBox.Visible = true;
            AllAccountsGroupbox.Visible = false;
        }

        private void CreateAccountButton_Click(object sender, EventArgs e)
        {
            // runs ValidateInput() to ensure proper inputs
            if (!(AccountManager.ValidateInput(
                CreateCustomerNameTextBox.Text,
                CreateInitialDepositTextBox.Text,
                CreateMinimumBalanceTextBox.Text,
                out decimal Balance,
                out decimal MinimumBalance,
                out string error)))
            {
                // if invalid input, show error and return
                CreateStatusLbl.ForeColor = Color.Red;
                CreateStatusLbl.Text = error;
                return;
            }

            // create account from information given
            if (AccountManager.CreateAccount(
                CreateCustomerNameTextBox.Text,
                Balance,
                MinimumBalance,
                out string NewAccountNumber,
                out error))
            {
                // show success message
                CreateStatusLbl.ForeColor = Color.Green;
                CreateStatusLbl.Text = $"Successfully created account. Account Name and Number: {CreateCustomerNameTextBox.Text} | {NewAccountNumber}";
            }
            else
            {
                // if failed to create account, show error
                CreateStatusLbl.ForeColor = Color.Red;
                CreateStatusLbl.Text = error;
            }
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            // declare variables for shortcuts later
            string ID = SearchCustomerIDTextbox.Text;
            string Name = SearchCustomerNameTextbox.Text;
            bool NameAndIDSearch = false;
            bool NameSearch = false;

            SearchStatusLbl.Text = string.Empty;

            // if statements to check which textbox is filled
            if (!string.IsNullOrWhiteSpace(Name))
            {
                if (!string.IsNullOrWhiteSpace(ID))
                {
                    NameAndIDSearch = true;
                }
                NameSearch = true;
            }

            // display error if both are blank
            if (string.IsNullOrWhiteSpace(ID) && string.IsNullOrWhiteSpace(Name))
            {
                SearchStatusLbl.ForeColor = Color.Red;
                SearchStatusLbl.Text = "Please enter ID and/or Name to search";
                return;
            }

            // If statements to determine which status message to show based on which textbox is filled
            List<Account> Match = AccountManager.FindAccount(Name, ID, NameSearch, NameAndIDSearch);

            SearchStatusLbl.ForeColor = Color.Black;
            if (NameAndIDSearch == true && Match != null)
                SearchStatusLbl.Text = $"Found {Match.Count()} account(s) with Name and ID matching: {Name} | {ID}";
            else if (NameSearch && Match != null)
                SearchStatusLbl.Text = $"Found {Match.Count()} account(s) with Name matching: {Name}";
            else if (Match != null)
                SearchStatusLbl.Text = $"Found {Match.Count()} account(s) with ID matching: {ID}";

            RefreshSearchAccountList(Match);
        }

        private void AccountsGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // function to take data from selected cell and show its data
            if (e.RowIndex >= 0)
            {
                Account selectedAccount = AccountsGrid.Rows[e.RowIndex].DataBoundItem as Account;
                if (selectedAccount != null)
                {
                    // Set all the textboxes to have the information from the account list
                    AllAccountsCurrentCustomerIDLbl.Text = selectedAccount.AccountNumber;
                    AllAccountsCurrentCustomerNameLbl.Text = selectedAccount.CustomerName;
                    AllAccountsCurrentCustomerBalanceLbl.Text = selectedAccount.Balance.ToString("C");
                    AllAccountsCurrentCustomerMinimumBalanceLbl.Text = selectedAccount.MinimumBalance.ToString("C");
                    AllAccountsCurrentCustomerCreatedLbl.Text = selectedAccount.DateCreated.ToString("f");
                }
            }
        }

        private void MainPage_Closing(object sender, FormClosingEventArgs e)
        {
            // function to save all accounts when closing
            AccountManager.SaveAccountsToJson();
        }

        private void HideTransactionPages(object sender, EventArgs e)
        {
            TransactionsGroupBox.Visible = false;
            DepositGroupBox.Visible = false;
            WithdrawGroupBox.Visible = false;
            TransferGroupBox.Visible = false;
        }

        private void TransactionsGroupBox_Enter(object sender, EventArgs e)
        {

        }

        private void TransactionHomeButton_Click(object sender, EventArgs e)
        {
            // Set home as visible and transactions as not visible
            TransactionsGroupBox.Visible = false;
            HomeGroupBox.Visible = true;
        }

        private void TransactionsPageButton_Click(object sender, EventArgs e)
        {
            // Set transactions page visible and home as not visible
            HomeGroupBox.Visible = false;
            TransactionsGroupBox.Visible = true;
        }

        private void DepositPageButton_Click(object sender, EventArgs e)
        {
            // Set deposit page visible and transactions as not visible
            TransactionsGroupBox.Visible = false;
            DepositGroupBox.Visible = true;
            DepositStatusLabel.Text = string.Empty;
            DepositPreviousBalanceLabel.Text = string.Empty;
            DepositUpdatedBalanceLabel.Text = string.Empty;

        }

        private void WithdrawPageButton_Click(object sender, EventArgs e)
        {
            // Set withdraw page visible and transactions page as not visible
            TransactionsGroupBox.Visible = false;
            WithdrawGroupBox.Visible = true;
            WithdrawStatusLabel.Text = string.Empty;
            WithdrawPreviousBalance.Text = string.Empty;
            WithdrawUpdatedBalance.Text = string.Empty;
        }

        private void TransferPageButton_Click(object sender, EventArgs e)
        {
            // Set transfer page visible and transactions page as not visible
            TransactionsGroupBox.Visible = false;
            TransferGroupBox.Visible = true;
            TransferStatusLabel.Text = string.Empty;
            TransferSenderPreviousBalance.Text = string.Empty;
            TransferSenderUpdatedBalance.Text = string.Empty;
            TransferReceiverPreviousBalance.Text = string.Empty;
            TransferReceiverUpdatedBalance.Text = string.Empty;
        }

        private void DepositGroupBox_Enter(object sender, EventArgs e)
        {

        }

        private void DepositBackButton_Click(object sender, EventArgs e)
        {
            DepositGroupBox.Visible = false;
            TransactionsGroupBox.Visible = true;
        }

        private void WithdrawGroupBox_Enter(object sender, EventArgs e)
        {

        }

        private void WithdrawBackButton_Click(object sender, EventArgs e)
        {
            WithdrawGroupBox.Visible = false;
            TransactionsGroupBox.Visible = true;
        }

        private void TransferGroupBox_Enter(object sender, EventArgs e)
        {

        }

        private void TransferBackButton_Click(object sender, EventArgs e)
        {
            TransferGroupBox.Visible = false;
            TransactionsGroupBox.Visible = true;
        }

        private void DepositButton_Click(object sender, EventArgs e)
        {
            // Get account number and deposit amount
            string accountNumber = DepositAccountNumberTextBox.Text;

            // Validate deposit amount
            if (!decimal.TryParse(DepositAmountTextBox.Text, out decimal amount))
            {
                DepositStatusLabel.ForeColor = Color.Red;
                DepositStatusLabel.Text = "Please enter a valid deposit amount.";
                return;
            }

            // Find the account
            List<Account> matches = AccountManager.FindAccount("", accountNumber, false, false);

            // Check if account exists
            if (matches.Count == 0)
            {
                DepositStatusLabel.ForeColor = Color.Red;
                DepositStatusLabel.Text = "Account not found.";
                return;
            }

            Account account = matches[0];
            decimal currentBalance = account.Balance;

            // Display current balance
            DepositPreviousBalanceLabel.Text = currentBalance.ToString("C");

            // Process deposit
            if (deposit.ProcessDeposit(accountNumber, amount))
            {
                // Calculate and display updated balance
                decimal updatedBalance = account.Balance;

                DepositUpdatedBalanceLabel.Text = updatedBalance.ToString("C");

                DepositStatusLabel.ForeColor = Color.Green;
                DepositStatusLabel.Text = "Deposit completed successfully!";
            }
            else
            {
                DepositStatusLabel.ForeColor = Color.Red;
                DepositStatusLabel.Text = "Deposit failed. Check the amount entered.";
            }
        }

        private void WithdrawButton_Click(object sender, EventArgs e)
        {
            // Get account number
            string accountNumber = WithdrawAccountNumberTextBox.Text;

            // Validate withdraw amount
            if (!decimal.TryParse(WithdrawAmountTextBox.Text, out decimal amount))
            {
                WithdrawStatusLabel.ForeColor = Color.Red;
                WithdrawStatusLabel.Text = "Please enter a valid withdraw amount.";
                return;
            }

            // Find the account
            List<Account> matches = AccountManager.FindAccount("", accountNumber, false, false);

            // Check if account exists
            if (matches.Count == 0)
            {
                WithdrawStatusLabel.ForeColor = Color.Red;
                WithdrawStatusLabel.Text = "Account not found.";
                return;
            }

            // Get account and current balance
            Account account = matches[0];
            decimal currentBalance = account.Balance;

            // Display current balance
            WithdrawPreviousBalance.Text = currentBalance.ToString("C");

            // Process withdraw
            if (withdraw.ProcessWithdraw(accountNumber, amount))
            {
                // Get and display updated balance
                decimal updatedBalance = account.Balance;

                WithdrawUpdatedBalance.Text = updatedBalance.ToString("C");

                WithdrawStatusLabel.ForeColor = Color.Green;
                WithdrawStatusLabel.Text = "Withdraw completed successfully!";
            }
            else
            {
                WithdrawStatusLabel.ForeColor = Color.Red;
                WithdrawStatusLabel.Text = "Withdraw failed. Check the amount and available balance.";
            }
        }

        private void TransferButton_Click(object sender, EventArgs e)
        {
            // Get account numbers
            string senderAccountNumber = TransferSenderAccountTextBox.Text;
            string receiverAccountNumber = TransferReceiverAccountTextBox.Text;

            // Validate transfer amount
            if (!decimal.TryParse(TransferAmountTextBox.Text, out decimal amount))
            {
                TransferStatusLabel.ForeColor = Color.Red;
                TransferStatusLabel.Text = "Please enter a valid transfer amount.";
                return;
            }

            // Find the sender account
            List<Account> senderMatches = AccountManager.FindAccount("", senderAccountNumber, false, false);

            // Check if sender account exists
            if (senderMatches.Count == 0)
            {
                TransferStatusLabel.ForeColor = Color.Red;
                TransferStatusLabel.Text = "Sender account not found.";
                return;
            }

            //Find the receiver account
            List<Account> receiverMatches = AccountManager.FindAccount("", receiverAccountNumber, false, false);

            // Check if receiver account exists
            if (receiverMatches.Count == 0)
            {
                TransferStatusLabel.ForeColor = Color.Red;
                TransferStatusLabel.Text = "Receiver account not found.";
                return;
            }

            // Get both accounts
            Account senderAccount = senderMatches[0];
            Account receiverAccount = receiverMatches[0];

            // Display previous balances
            TransferSenderPreviousBalance.Text = senderAccount.Balance.ToString("C");
            TransferReceiverPreviousBalance.Text = receiverAccount.Balance.ToString("C");

            // Process transfer
            if (transfer.ProcessTransfer(senderAccountNumber, receiverAccountNumber, amount))
            {
                // Display updated balances
                TransferSenderUpdatedBalance.Text = senderAccount.Balance.ToString("C");
                TransferReceiverUpdatedBalance.Text = receiverAccount.Balance.ToString("C");

                TransferStatusLabel.ForeColor = Color.Green;
                TransferStatusLabel.Text = "Transfer completed successfully!";
            }
            else
            {
                TransferStatusLabel.ForeColor = Color.Red;
                TransferStatusLabel.Text = "Transfer failed. Check the amount, accounts, and available balance.";
            }
        }
    }
}
