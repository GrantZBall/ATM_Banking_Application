﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

namespace AccountManagement
{
    public class Transfer
    {
        private AccountManager accountManager;

        public Transfer(AccountManager accountManager)
        {
            this.accountManager = accountManager;
        }

        public bool ProcessTransfer(
            string senderAccountNumber,
            string receiverAccountNumber,
            decimal amount)
        {
            // Check that the amount is positive
            if (amount <= 0)
            {
                return false;
            }

            // Prevent transferring to the same account 
            if (senderAccountNumber == receiverAccountNumber)
            {
                return false;
            }

            //Find the sending account
            List<Account> senderMatches = accountManager.FindAccount("", senderAccountNumber, false, false);

            //Find the receiving account
            List<Account> receiverMatches = accountManager.FindAccount("", receiverAccountNumber, false, false);

            //Check that both accounts exist
            if (senderMatches.Count == 0 || receiverMatches.Count == 0)
            {
                return false;
            }

            //Get both accounts
            Account sender = senderMatches[0];
            Account receiver = receiverMatches[0];

            // Withdraw from sender
            bool withdrawSuccess = sender.Withdraw(amount);

            if (!withdrawSuccess)
            {
                return false;
            }

            // Deposit into receiver
            bool depositSuccess = receiver.Deposit(amount);

            //Restore sender balance if deposit fails
            if (!depositSuccess)
            {
                sender.Deposit(amount);
                return false;
            }

            //Save account changes
            accountManager.SaveAccountsToJson();

            return true;
        }
    }
}
