﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountManagement
{
    public class Deposit
    {
        private AccountManager accountManager;

        public Deposit(AccountManager accountManager)
        {
            this.accountManager = accountManager;
        }

        public bool ProcessDeposit(string accountNumber, decimal amount)
        {
            // Find the account
            List<Account> matches = accountManager.FindAccount("", accountNumber, false, false);

            // Check if account exists
            if (matches.Count == 0)
            {
                return false;
            }

            // Get the account
            Account account = matches[0];

            // Process deposit
            bool success = account.Deposit(amount);

            // Save changes
            if (success)
            {
                accountManager.SaveAccountsToJson();
            }

            return success;
        }
    }
}
