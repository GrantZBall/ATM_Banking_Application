﻿namespace AccountManagement
{
    partial class MainPage
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            WelcomeLbl = new Label();
            HomeGroupBox = new GroupBox();
            TransactionsPageButton = new Button();
            ViewAllAccountsPageButton = new Button();
            SearchAccountPageButton = new Button();
            CreateAccountPageButton = new Button();
            CreateAccountGroupBox = new GroupBox();
            CreateStatusLbl = new Label();
            CreateMinimumBalanceTextBox = new TextBox();
            CreateMinimumBalanceLbl = new Label();
            CreateInitialDepositTextBox = new TextBox();
            CreateInitialDepositLbl = new Label();
            CreateCustomerNameTextBox = new TextBox();
            CreateCustomerNameLbl = new Label();
            CreateHomeButton = new Button();
            CreateAccountButton = new Button();
            CreateAccountLbl = new Label();
            AllAccountsGroupbox = new GroupBox();
            AllAccountsCurrentCustomerIDLbl = new Label();
            AllAccountsCurrentCustomerCreatedLbl = new Label();
            AllAccountsCurrentCustomerMinimumBalanceLbl = new Label();
            AllAccountsCurrentCustomerBalanceLbl = new Label();
            AllAccountsCurrentCustomerNameLbl = new Label();
            AllAccountsCustomerIDLbl = new Label();
            AccountsGrid = new DataGridView();
            AllAccountsDateCreatedLbl = new Label();
            AllAccountsMinimumBalanceLbl = new Label();
            AllAccountsCurrentBalanceLbl = new Label();
            AllAccountsCustomerNameLbl = new Label();
            AllAccountsHomeButton = new Button();
            AllAccountsLbl = new Label();
            SearchAccountGroupBox = new GroupBox();
            SearchEnterIDORNameLbl = new Label();
            SearchAccountsGrid = new DataGridView();
            SearchStatusLbl = new Label();
            SearchCustomerIDTextbox = new TextBox();
            SearchWithIDLbl = new Label();
            SearchCustomerNameTextbox = new TextBox();
            SearchWithNameLbl = new Label();
            SearchHomeButton = new Button();
            SearchButton = new Button();
            SearchAccountLbl = new Label();
            TransactionsGroupBox = new GroupBox();
            TransferPageButton = new Button();
            WithdrawPageButton = new Button();
            DepositPageButton = new Button();
            TransactionHomeButton = new Button();
            DepositGroupBox = new GroupBox();
            DepositNewBalance = new Label();
            DepositOldBalanceLabel = new Label();
            DepositUpdatedBalanceLabel = new Label();
            DepositPreviousBalanceLabel = new Label();
            DepositStatusLabel = new Label();
            DepositButton = new Button();
            DepositAmountTextBox = new TextBox();
            DepositAccountNumberTextBox = new TextBox();
            DepositAmountLabel = new Label();
            DepositAccountNumberLabel = new Label();
            DepositBackButton = new Button();
            WithdrawGroupBox = new GroupBox();
            WithdrawUpdatedBalance = new Label();
            WithdrawPreviousBalance = new Label();
            WithdrawStatusLabel = new Label();
            WithdrawNewBalanceLabel = new Label();
            WithdrawOldBalanceLabel = new Label();
            WithdrawAmountTextBox = new TextBox();
            WithdrawAccountNumberTextBox = new TextBox();
            WithdrawAmountLabel = new Label();
            WithdrawAccountNumberLabel = new Label();
            WithdrawButton = new Button();
            WithdrawBackButton = new Button();
            TransferGroupBox = new GroupBox();
            TransferReceiverUpdatedBalance = new Label();
            TransferReceiverNewBalance = new Label();
            TransferReceiverPreviousBalance = new Label();
            TransferReceiverOldBalance = new Label();
            TransferSenderUpdatedBalance = new Label();
            TransferSenderNewBalance = new Label();
            TransferSenderPreviousBalance = new Label();
            TransferSenderOldBalanceLabel = new Label();
            TransferStatusLabel = new Label();
            TransferButton = new Button();
            TransferAmountTextBox = new TextBox();
            TransferAmountLabel = new Label();
            TransferReceiverAccountTextBox = new TextBox();
            TransferReceiverAccountLabel = new Label();
            TransferSenderAccountTextBox = new TextBox();
            TransferSenderAccountLabel = new Label();
            TransferBackButton = new Button();
            HomeGroupBox.SuspendLayout();
            CreateAccountGroupBox.SuspendLayout();
            AllAccountsGroupbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)AccountsGrid).BeginInit();
            SearchAccountGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)SearchAccountsGrid).BeginInit();
            TransactionsGroupBox.SuspendLayout();
            DepositGroupBox.SuspendLayout();
            WithdrawGroupBox.SuspendLayout();
            TransferGroupBox.SuspendLayout();
            SuspendLayout();
            // 
            // WelcomeLbl
            // 
            WelcomeLbl.AutoSize = true;
            WelcomeLbl.Font = new Font("Sylfaen", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            WelcomeLbl.Location = new Point(114, 127);
            WelcomeLbl.Margin = new Padding(4, 0, 4, 0);
            WelcomeLbl.Name = "WelcomeLbl";
            WelcomeLbl.Size = new Size(577, 47);
            WelcomeLbl.TabIndex = 0;
            WelcomeLbl.Text = "Thank you for using ATM Banking";
            // 
            // HomeGroupBox
            // 
            HomeGroupBox.Controls.Add(TransactionsPageButton);
            HomeGroupBox.Controls.Add(ViewAllAccountsPageButton);
            HomeGroupBox.Controls.Add(SearchAccountPageButton);
            HomeGroupBox.Controls.Add(CreateAccountPageButton);
            HomeGroupBox.Controls.Add(WelcomeLbl);
            HomeGroupBox.Location = new Point(17, 20);
            HomeGroupBox.Margin = new Padding(4, 5, 4, 5);
            HomeGroupBox.Name = "HomeGroupBox";
            HomeGroupBox.Padding = new Padding(4, 5, 4, 5);
            HomeGroupBox.Size = new Size(796, 762);
            HomeGroupBox.TabIndex = 1;
            HomeGroupBox.TabStop = false;
            HomeGroupBox.Visible = false;
            // 
            // TransactionsPageButton
            // 
            TransactionsPageButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            TransactionsPageButton.Location = new Point(249, 280);
            TransactionsPageButton.Margin = new Padding(4, 5, 4, 5);
            TransactionsPageButton.Name = "TransactionsPageButton";
            TransactionsPageButton.Size = new Size(297, 72);
            TransactionsPageButton.TabIndex = 4;
            TransactionsPageButton.Text = "Transactions";
            TransactionsPageButton.UseVisualStyleBackColor = true;
            TransactionsPageButton.Click += TransactionsPageButton_Click;
            // 
            // ViewAllAccountsPageButton
            // 
            ViewAllAccountsPageButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewAllAccountsPageButton.Location = new Point(249, 445);
            ViewAllAccountsPageButton.Margin = new Padding(4, 5, 4, 5);
            ViewAllAccountsPageButton.Name = "ViewAllAccountsPageButton";
            ViewAllAccountsPageButton.Size = new Size(297, 72);
            ViewAllAccountsPageButton.TabIndex = 3;
            ViewAllAccountsPageButton.Text = "View All Accounts";
            ViewAllAccountsPageButton.UseVisualStyleBackColor = true;
            ViewAllAccountsPageButton.Click += ViewAllAccountsPageButton_Click;
            // 
            // SearchAccountPageButton
            // 
            SearchAccountPageButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchAccountPageButton.Location = new Point(249, 363);
            SearchAccountPageButton.Margin = new Padding(4, 5, 4, 5);
            SearchAccountPageButton.Name = "SearchAccountPageButton";
            SearchAccountPageButton.Size = new Size(297, 72);
            SearchAccountPageButton.TabIndex = 2;
            SearchAccountPageButton.Text = "Search Account";
            SearchAccountPageButton.UseVisualStyleBackColor = true;
            SearchAccountPageButton.Click += SearchAccountPageButton_Click;
            // 
            // CreateAccountPageButton
            // 
            CreateAccountPageButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateAccountPageButton.Location = new Point(249, 198);
            CreateAccountPageButton.Margin = new Padding(4, 5, 4, 5);
            CreateAccountPageButton.Name = "CreateAccountPageButton";
            CreateAccountPageButton.Size = new Size(297, 72);
            CreateAccountPageButton.TabIndex = 1;
            CreateAccountPageButton.Text = "Create Account";
            CreateAccountPageButton.UseVisualStyleBackColor = true;
            CreateAccountPageButton.Click += CreateAccountPageButton_Click;
            // 
            // CreateAccountGroupBox
            // 
            CreateAccountGroupBox.Controls.Add(CreateStatusLbl);
            CreateAccountGroupBox.Controls.Add(CreateMinimumBalanceTextBox);
            CreateAccountGroupBox.Controls.Add(CreateMinimumBalanceLbl);
            CreateAccountGroupBox.Controls.Add(CreateInitialDepositTextBox);
            CreateAccountGroupBox.Controls.Add(CreateInitialDepositLbl);
            CreateAccountGroupBox.Controls.Add(CreateCustomerNameTextBox);
            CreateAccountGroupBox.Controls.Add(CreateCustomerNameLbl);
            CreateAccountGroupBox.Controls.Add(CreateHomeButton);
            CreateAccountGroupBox.Controls.Add(CreateAccountButton);
            CreateAccountGroupBox.Controls.Add(CreateAccountLbl);
            CreateAccountGroupBox.Location = new Point(17, 20);
            CreateAccountGroupBox.Margin = new Padding(4, 5, 4, 5);
            CreateAccountGroupBox.Name = "CreateAccountGroupBox";
            CreateAccountGroupBox.Padding = new Padding(4, 5, 4, 5);
            CreateAccountGroupBox.Size = new Size(796, 762);
            CreateAccountGroupBox.TabIndex = 4;
            CreateAccountGroupBox.TabStop = false;
            CreateAccountGroupBox.Visible = false;
            // 
            // CreateStatusLbl
            // 
            CreateStatusLbl.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CreateStatusLbl.Location = new Point(9, 600);
            CreateStatusLbl.Margin = new Padding(4, 0, 4, 0);
            CreateStatusLbl.Name = "CreateStatusLbl";
            CreateStatusLbl.Size = new Size(779, 83);
            CreateStatusLbl.TabIndex = 11;
            CreateStatusLbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // CreateMinimumBalanceTextBox
            // 
            CreateMinimumBalanceTextBox.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CreateMinimumBalanceTextBox.Location = new Point(411, 363);
            CreateMinimumBalanceTextBox.Margin = new Padding(4, 5, 4, 5);
            CreateMinimumBalanceTextBox.Name = "CreateMinimumBalanceTextBox";
            CreateMinimumBalanceTextBox.PlaceholderText = "Ex. 200";
            CreateMinimumBalanceTextBox.Size = new Size(267, 45);
            CreateMinimumBalanceTextBox.TabIndex = 10;
            // 
            // CreateMinimumBalanceLbl
            // 
            CreateMinimumBalanceLbl.AutoSize = true;
            CreateMinimumBalanceLbl.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateMinimumBalanceLbl.Location = new Point(114, 368);
            CreateMinimumBalanceLbl.Margin = new Padding(4, 0, 4, 0);
            CreateMinimumBalanceLbl.Name = "CreateMinimumBalanceLbl";
            CreateMinimumBalanceLbl.Size = new Size(309, 40);
            CreateMinimumBalanceLbl.TabIndex = 9;
            CreateMinimumBalanceLbl.Text = "Minimum Balance  . . .";
            // 
            // CreateInitialDepositTextBox
            // 
            CreateInitialDepositTextBox.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CreateInitialDepositTextBox.Location = new Point(411, 298);
            CreateInitialDepositTextBox.Margin = new Padding(4, 5, 4, 5);
            CreateInitialDepositTextBox.Name = "CreateInitialDepositTextBox";
            CreateInitialDepositTextBox.PlaceholderText = "Ex. 1500";
            CreateInitialDepositTextBox.Size = new Size(267, 45);
            CreateInitialDepositTextBox.TabIndex = 8;
            // 
            // CreateInitialDepositLbl
            // 
            CreateInitialDepositLbl.AutoSize = true;
            CreateInitialDepositLbl.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateInitialDepositLbl.Location = new Point(114, 303);
            CreateInitialDepositLbl.Margin = new Padding(4, 0, 4, 0);
            CreateInitialDepositLbl.Name = "CreateInitialDepositLbl";
            CreateInitialDepositLbl.Size = new Size(305, 40);
            CreateInitialDepositLbl.TabIndex = 7;
            CreateInitialDepositLbl.Text = "Initial Deposit . . . . . . .";
            // 
            // CreateCustomerNameTextBox
            // 
            CreateCustomerNameTextBox.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CreateCustomerNameTextBox.Location = new Point(411, 230);
            CreateCustomerNameTextBox.Margin = new Padding(4, 5, 4, 5);
            CreateCustomerNameTextBox.Name = "CreateCustomerNameTextBox";
            CreateCustomerNameTextBox.PlaceholderText = "Ex. John Smith";
            CreateCustomerNameTextBox.Size = new Size(267, 45);
            CreateCustomerNameTextBox.TabIndex = 6;
            // 
            // CreateCustomerNameLbl
            // 
            CreateCustomerNameLbl.AutoSize = true;
            CreateCustomerNameLbl.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateCustomerNameLbl.Location = new Point(114, 235);
            CreateCustomerNameLbl.Margin = new Padding(4, 0, 4, 0);
            CreateCustomerNameLbl.Name = "CreateCustomerNameLbl";
            CreateCustomerNameLbl.Size = new Size(305, 40);
            CreateCustomerNameLbl.TabIndex = 5;
            CreateCustomerNameLbl.Text = "Customer Name . . . . .";
            // 
            // CreateHomeButton
            // 
            CreateHomeButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateHomeButton.Location = new Point(9, 28);
            CreateHomeButton.Margin = new Padding(4, 5, 4, 5);
            CreateHomeButton.Name = "CreateHomeButton";
            CreateHomeButton.Size = new Size(116, 72);
            CreateHomeButton.TabIndex = 4;
            CreateHomeButton.Text = "Home";
            CreateHomeButton.UseVisualStyleBackColor = true;
            CreateHomeButton.Click += CreateHomeButton_Click;
            // 
            // CreateAccountButton
            // 
            CreateAccountButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateAccountButton.Location = new Point(249, 478);
            CreateAccountButton.Margin = new Padding(4, 5, 4, 5);
            CreateAccountButton.Name = "CreateAccountButton";
            CreateAccountButton.Size = new Size(297, 72);
            CreateAccountButton.TabIndex = 1;
            CreateAccountButton.Text = "Create Account";
            CreateAccountButton.UseVisualStyleBackColor = true;
            CreateAccountButton.Click += CreateAccountButton_Click;
            // 
            // CreateAccountLbl
            // 
            CreateAccountLbl.AutoSize = true;
            CreateAccountLbl.Font = new Font("Sylfaen", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateAccountLbl.Location = new Point(263, 48);
            CreateAccountLbl.Margin = new Padding(4, 0, 4, 0);
            CreateAccountLbl.Name = "CreateAccountLbl";
            CreateAccountLbl.Size = new Size(269, 47);
            CreateAccountLbl.TabIndex = 0;
            CreateAccountLbl.Text = "Create Account";
            // 
            // AllAccountsGroupbox
            // 
            AllAccountsGroupbox.Controls.Add(AllAccountsCurrentCustomerIDLbl);
            AllAccountsGroupbox.Controls.Add(AllAccountsCurrentCustomerCreatedLbl);
            AllAccountsGroupbox.Controls.Add(AllAccountsCurrentCustomerMinimumBalanceLbl);
            AllAccountsGroupbox.Controls.Add(AllAccountsCurrentCustomerBalanceLbl);
            AllAccountsGroupbox.Controls.Add(AllAccountsCurrentCustomerNameLbl);
            AllAccountsGroupbox.Controls.Add(AllAccountsCustomerIDLbl);
            AllAccountsGroupbox.Controls.Add(AccountsGrid);
            AllAccountsGroupbox.Controls.Add(AllAccountsDateCreatedLbl);
            AllAccountsGroupbox.Controls.Add(AllAccountsMinimumBalanceLbl);
            AllAccountsGroupbox.Controls.Add(AllAccountsCurrentBalanceLbl);
            AllAccountsGroupbox.Controls.Add(AllAccountsCustomerNameLbl);
            AllAccountsGroupbox.Controls.Add(AllAccountsHomeButton);
            AllAccountsGroupbox.Controls.Add(AllAccountsLbl);
            AllAccountsGroupbox.Location = new Point(17, 20);
            AllAccountsGroupbox.Margin = new Padding(4, 5, 4, 5);
            AllAccountsGroupbox.Name = "AllAccountsGroupbox";
            AllAccountsGroupbox.Padding = new Padding(4, 5, 4, 5);
            AllAccountsGroupbox.Size = new Size(796, 762);
            AllAccountsGroupbox.TabIndex = 12;
            AllAccountsGroupbox.TabStop = false;
            AllAccountsGroupbox.Visible = false;
            // 
            // AllAccountsCurrentCustomerIDLbl
            // 
            AllAccountsCurrentCustomerIDLbl.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AllAccountsCurrentCustomerIDLbl.Location = new Point(233, 127);
            AllAccountsCurrentCustomerIDLbl.Margin = new Padding(4, 0, 4, 0);
            AllAccountsCurrentCustomerIDLbl.Name = "AllAccountsCurrentCustomerIDLbl";
            AllAccountsCurrentCustomerIDLbl.Size = new Size(554, 33);
            AllAccountsCurrentCustomerIDLbl.TabIndex = 19;
            // 
            // AllAccountsCurrentCustomerCreatedLbl
            // 
            AllAccountsCurrentCustomerCreatedLbl.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AllAccountsCurrentCustomerCreatedLbl.Location = new Point(233, 293);
            AllAccountsCurrentCustomerCreatedLbl.Margin = new Padding(4, 0, 4, 0);
            AllAccountsCurrentCustomerCreatedLbl.Name = "AllAccountsCurrentCustomerCreatedLbl";
            AllAccountsCurrentCustomerCreatedLbl.Size = new Size(554, 33);
            AllAccountsCurrentCustomerCreatedLbl.TabIndex = 18;
            // 
            // AllAccountsCurrentCustomerMinimumBalanceLbl
            // 
            AllAccountsCurrentCustomerMinimumBalanceLbl.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AllAccountsCurrentCustomerMinimumBalanceLbl.Location = new Point(233, 252);
            AllAccountsCurrentCustomerMinimumBalanceLbl.Margin = new Padding(4, 0, 4, 0);
            AllAccountsCurrentCustomerMinimumBalanceLbl.Name = "AllAccountsCurrentCustomerMinimumBalanceLbl";
            AllAccountsCurrentCustomerMinimumBalanceLbl.Size = new Size(554, 33);
            AllAccountsCurrentCustomerMinimumBalanceLbl.TabIndex = 17;
            // 
            // AllAccountsCurrentCustomerBalanceLbl
            // 
            AllAccountsCurrentCustomerBalanceLbl.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AllAccountsCurrentCustomerBalanceLbl.Location = new Point(233, 210);
            AllAccountsCurrentCustomerBalanceLbl.Margin = new Padding(4, 0, 4, 0);
            AllAccountsCurrentCustomerBalanceLbl.Name = "AllAccountsCurrentCustomerBalanceLbl";
            AllAccountsCurrentCustomerBalanceLbl.Size = new Size(554, 33);
            AllAccountsCurrentCustomerBalanceLbl.TabIndex = 16;
            // 
            // AllAccountsCurrentCustomerNameLbl
            // 
            AllAccountsCurrentCustomerNameLbl.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AllAccountsCurrentCustomerNameLbl.Location = new Point(233, 170);
            AllAccountsCurrentCustomerNameLbl.Margin = new Padding(4, 0, 4, 0);
            AllAccountsCurrentCustomerNameLbl.Name = "AllAccountsCurrentCustomerNameLbl";
            AllAccountsCurrentCustomerNameLbl.Size = new Size(554, 33);
            AllAccountsCurrentCustomerNameLbl.TabIndex = 15;
            // 
            // AllAccountsCustomerIDLbl
            // 
            AllAccountsCustomerIDLbl.AutoSize = true;
            AllAccountsCustomerIDLbl.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AllAccountsCustomerIDLbl.Location = new Point(9, 127);
            AllAccountsCustomerIDLbl.Margin = new Padding(4, 0, 4, 0);
            AllAccountsCustomerIDLbl.Name = "AllAccountsCustomerIDLbl";
            AllAccountsCustomerIDLbl.Size = new Size(227, 30);
            AllAccountsCustomerIDLbl.TabIndex = 14;
            AllAccountsCustomerIDLbl.Text = "Account Number . . . .";
            // 
            // AccountsGrid
            // 
            AccountsGrid.AccessibleRole = AccessibleRole.None;
            AccountsGrid.AllowUserToAddRows = false;
            AccountsGrid.AllowUserToDeleteRows = false;
            AccountsGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            AccountsGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            AccountsGrid.ImeMode = ImeMode.NoControl;
            AccountsGrid.Location = new Point(9, 337);
            AccountsGrid.Margin = new Padding(4, 5, 4, 5);
            AccountsGrid.MultiSelect = false;
            AccountsGrid.Name = "AccountsGrid";
            AccountsGrid.ReadOnly = true;
            AccountsGrid.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            AccountsGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            AccountsGrid.Size = new Size(779, 415);
            AccountsGrid.TabIndex = 13;
            AccountsGrid.TabStop = false;
            AccountsGrid.CellClick += AccountsGrid_CellClick;
            // 
            // AllAccountsDateCreatedLbl
            // 
            AllAccountsDateCreatedLbl.AutoSize = true;
            AllAccountsDateCreatedLbl.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AllAccountsDateCreatedLbl.Location = new Point(9, 293);
            AllAccountsDateCreatedLbl.Margin = new Padding(4, 0, 4, 0);
            AllAccountsDateCreatedLbl.Name = "AllAccountsDateCreatedLbl";
            AllAccountsDateCreatedLbl.Size = new Size(227, 30);
            AllAccountsDateCreatedLbl.TabIndex = 12;
            AllAccountsDateCreatedLbl.Text = "Date Created  . . . . . . .";
            // 
            // AllAccountsMinimumBalanceLbl
            // 
            AllAccountsMinimumBalanceLbl.AutoSize = true;
            AllAccountsMinimumBalanceLbl.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AllAccountsMinimumBalanceLbl.Location = new Point(9, 252);
            AllAccountsMinimumBalanceLbl.Margin = new Padding(4, 0, 4, 0);
            AllAccountsMinimumBalanceLbl.Name = "AllAccountsMinimumBalanceLbl";
            AllAccountsMinimumBalanceLbl.Size = new Size(230, 30);
            AllAccountsMinimumBalanceLbl.TabIndex = 9;
            AllAccountsMinimumBalanceLbl.Text = "Minimum Balance  . . .";
            // 
            // AllAccountsCurrentBalanceLbl
            // 
            AllAccountsCurrentBalanceLbl.AutoSize = true;
            AllAccountsCurrentBalanceLbl.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AllAccountsCurrentBalanceLbl.Location = new Point(9, 210);
            AllAccountsCurrentBalanceLbl.Margin = new Padding(4, 0, 4, 0);
            AllAccountsCurrentBalanceLbl.Name = "AllAccountsCurrentBalanceLbl";
            AllAccountsCurrentBalanceLbl.Size = new Size(226, 30);
            AllAccountsCurrentBalanceLbl.TabIndex = 7;
            AllAccountsCurrentBalanceLbl.Text = "Current Balance . . . . .";
            // 
            // AllAccountsCustomerNameLbl
            // 
            AllAccountsCustomerNameLbl.AutoSize = true;
            AllAccountsCustomerNameLbl.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AllAccountsCustomerNameLbl.Location = new Point(9, 168);
            AllAccountsCustomerNameLbl.Margin = new Padding(4, 0, 4, 0);
            AllAccountsCustomerNameLbl.Name = "AllAccountsCustomerNameLbl";
            AllAccountsCustomerNameLbl.Size = new Size(229, 30);
            AllAccountsCustomerNameLbl.TabIndex = 5;
            AllAccountsCustomerNameLbl.Text = "Customer Name . . . . .";
            // 
            // AllAccountsHomeButton
            // 
            AllAccountsHomeButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AllAccountsHomeButton.Location = new Point(9, 28);
            AllAccountsHomeButton.Margin = new Padding(4, 5, 4, 5);
            AllAccountsHomeButton.Name = "AllAccountsHomeButton";
            AllAccountsHomeButton.Size = new Size(116, 72);
            AllAccountsHomeButton.TabIndex = 4;
            AllAccountsHomeButton.Text = "Home";
            AllAccountsHomeButton.UseVisualStyleBackColor = true;
            AllAccountsHomeButton.Click += AllAccountsHomeButton_Click;
            // 
            // AllAccountsLbl
            // 
            AllAccountsLbl.AutoSize = true;
            AllAccountsLbl.Font = new Font("Sylfaen", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AllAccountsLbl.Location = new Point(263, 48);
            AllAccountsLbl.Margin = new Padding(4, 0, 4, 0);
            AllAccountsLbl.Name = "AllAccountsLbl";
            AllAccountsLbl.Size = new Size(227, 47);
            AllAccountsLbl.TabIndex = 0;
            AllAccountsLbl.Text = "All Accounts";
            // 
            // SearchAccountGroupBox
            // 
            SearchAccountGroupBox.Controls.Add(SearchEnterIDORNameLbl);
            SearchAccountGroupBox.Controls.Add(SearchAccountsGrid);
            SearchAccountGroupBox.Controls.Add(SearchStatusLbl);
            SearchAccountGroupBox.Controls.Add(SearchCustomerIDTextbox);
            SearchAccountGroupBox.Controls.Add(SearchWithIDLbl);
            SearchAccountGroupBox.Controls.Add(SearchCustomerNameTextbox);
            SearchAccountGroupBox.Controls.Add(SearchWithNameLbl);
            SearchAccountGroupBox.Controls.Add(SearchHomeButton);
            SearchAccountGroupBox.Controls.Add(SearchButton);
            SearchAccountGroupBox.Controls.Add(SearchAccountLbl);
            SearchAccountGroupBox.Location = new Point(17, 20);
            SearchAccountGroupBox.Margin = new Padding(4, 5, 4, 5);
            SearchAccountGroupBox.Name = "SearchAccountGroupBox";
            SearchAccountGroupBox.Padding = new Padding(4, 5, 4, 5);
            SearchAccountGroupBox.Size = new Size(796, 762);
            SearchAccountGroupBox.TabIndex = 12;
            SearchAccountGroupBox.TabStop = false;
            SearchAccountGroupBox.Visible = false;
            // 
            // SearchEnterIDORNameLbl
            // 
            SearchEnterIDORNameLbl.AutoSize = true;
            SearchEnterIDORNameLbl.Location = new Point(207, 102);
            SearchEnterIDORNameLbl.Margin = new Padding(4, 0, 4, 0);
            SearchEnterIDORNameLbl.Name = "SearchEnterIDORNameLbl";
            SearchEnterIDORNameLbl.Size = new Size(404, 25);
            SearchEnterIDORNameLbl.TabIndex = 12;
            SearchEnterIDORNameLbl.Text = "Please enter Customer Name and/or Customer ID";
            // 
            // SearchAccountsGrid
            // 
            SearchAccountsGrid.AccessibleRole = AccessibleRole.None;
            SearchAccountsGrid.AllowUserToAddRows = false;
            SearchAccountsGrid.AllowUserToDeleteRows = false;
            SearchAccountsGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            SearchAccountsGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            SearchAccountsGrid.ImeMode = ImeMode.NoControl;
            SearchAccountsGrid.Location = new Point(9, 448);
            SearchAccountsGrid.Margin = new Padding(4, 5, 4, 5);
            SearchAccountsGrid.MultiSelect = false;
            SearchAccountsGrid.Name = "SearchAccountsGrid";
            SearchAccountsGrid.ReadOnly = true;
            SearchAccountsGrid.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            SearchAccountsGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            SearchAccountsGrid.Size = new Size(779, 303);
            SearchAccountsGrid.TabIndex = 0;
            SearchAccountsGrid.TabStop = false;
            // 
            // SearchStatusLbl
            // 
            SearchStatusLbl.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            SearchStatusLbl.Location = new Point(0, 400);
            SearchStatusLbl.Margin = new Padding(4, 0, 4, 0);
            SearchStatusLbl.Name = "SearchStatusLbl";
            SearchStatusLbl.Size = new Size(787, 40);
            SearchStatusLbl.TabIndex = 11;
            SearchStatusLbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // SearchCustomerIDTextbox
            // 
            SearchCustomerIDTextbox.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            SearchCustomerIDTextbox.Location = new Point(411, 225);
            SearchCustomerIDTextbox.Margin = new Padding(4, 5, 4, 5);
            SearchCustomerIDTextbox.Name = "SearchCustomerIDTextbox";
            SearchCustomerIDTextbox.PlaceholderText = "Ex. 1001";
            SearchCustomerIDTextbox.Size = new Size(267, 45);
            SearchCustomerIDTextbox.TabIndex = 8;
            // 
            // SearchWithIDLbl
            // 
            SearchWithIDLbl.AutoSize = true;
            SearchWithIDLbl.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchWithIDLbl.Location = new Point(114, 230);
            SearchWithIDLbl.Margin = new Padding(4, 0, 4, 0);
            SearchWithIDLbl.Name = "SearchWithIDLbl";
            SearchWithIDLbl.Size = new Size(301, 40);
            SearchWithIDLbl.TabIndex = 7;
            SearchWithIDLbl.Text = "Customer ID . . . . . . . .";
            // 
            // SearchCustomerNameTextbox
            // 
            SearchCustomerNameTextbox.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            SearchCustomerNameTextbox.Location = new Point(411, 157);
            SearchCustomerNameTextbox.Margin = new Padding(4, 5, 4, 5);
            SearchCustomerNameTextbox.Name = "SearchCustomerNameTextbox";
            SearchCustomerNameTextbox.PlaceholderText = "Ex. John Smith";
            SearchCustomerNameTextbox.Size = new Size(267, 45);
            SearchCustomerNameTextbox.TabIndex = 6;
            // 
            // SearchWithNameLbl
            // 
            SearchWithNameLbl.AutoSize = true;
            SearchWithNameLbl.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchWithNameLbl.Location = new Point(114, 162);
            SearchWithNameLbl.Margin = new Padding(4, 0, 4, 0);
            SearchWithNameLbl.Name = "SearchWithNameLbl";
            SearchWithNameLbl.Size = new Size(305, 40);
            SearchWithNameLbl.TabIndex = 5;
            SearchWithNameLbl.Text = "Customer Name . . . . .";
            // 
            // SearchHomeButton
            // 
            SearchHomeButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchHomeButton.Location = new Point(9, 28);
            SearchHomeButton.Margin = new Padding(4, 5, 4, 5);
            SearchHomeButton.Name = "SearchHomeButton";
            SearchHomeButton.Size = new Size(116, 72);
            SearchHomeButton.TabIndex = 4;
            SearchHomeButton.Text = "Home";
            SearchHomeButton.UseVisualStyleBackColor = true;
            SearchHomeButton.Click += SearchHomeButton_Click;
            // 
            // SearchButton
            // 
            SearchButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchButton.Location = new Point(249, 323);
            SearchButton.Margin = new Padding(4, 5, 4, 5);
            SearchButton.Name = "SearchButton";
            SearchButton.Size = new Size(297, 72);
            SearchButton.TabIndex = 1;
            SearchButton.Text = "Search";
            SearchButton.UseVisualStyleBackColor = true;
            SearchButton.Click += SearchButton_Click;
            // 
            // SearchAccountLbl
            // 
            SearchAccountLbl.AutoSize = true;
            SearchAccountLbl.Font = new Font("Sylfaen", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchAccountLbl.Location = new Point(233, 48);
            SearchAccountLbl.Margin = new Padding(4, 0, 4, 0);
            SearchAccountLbl.Name = "SearchAccountLbl";
            SearchAccountLbl.Size = new Size(335, 47);
            SearchAccountLbl.TabIndex = 0;
            SearchAccountLbl.Text = "Search For Account";
            // 
            // TransactionsGroupBox
            // 
            TransactionsGroupBox.Controls.Add(TransferPageButton);
            TransactionsGroupBox.Controls.Add(WithdrawPageButton);
            TransactionsGroupBox.Controls.Add(DepositPageButton);
            TransactionsGroupBox.Controls.Add(TransactionHomeButton);
            TransactionsGroupBox.Location = new Point(12, 24);
            TransactionsGroupBox.Name = "TransactionsGroupBox";
            TransactionsGroupBox.Size = new Size(796, 750);
            TransactionsGroupBox.TabIndex = 13;
            TransactionsGroupBox.TabStop = false;
            TransactionsGroupBox.Enter += TransactionsGroupBox_Enter;
            // 
            // TransferPageButton
            // 
            TransferPageButton.Location = new Point(533, 449);
            TransferPageButton.Name = "TransferPageButton";
            TransferPageButton.Size = new Size(112, 34);
            TransferPageButton.TabIndex = 6;
            TransferPageButton.Text = "Transfer";
            TransferPageButton.UseVisualStyleBackColor = true;
            TransferPageButton.Click += TransferPageButton_Click;
            // 
            // WithdrawPageButton
            // 
            WithdrawPageButton.Location = new Point(340, 448);
            WithdrawPageButton.Name = "WithdrawPageButton";
            WithdrawPageButton.Size = new Size(112, 34);
            WithdrawPageButton.TabIndex = 5;
            WithdrawPageButton.Text = "Withdraw";
            WithdrawPageButton.UseVisualStyleBackColor = true;
            WithdrawPageButton.Click += WithdrawPageButton_Click;
            // 
            // DepositPageButton
            // 
            DepositPageButton.Location = new Point(149, 438);
            DepositPageButton.Name = "DepositPageButton";
            DepositPageButton.Size = new Size(112, 34);
            DepositPageButton.TabIndex = 4;
            DepositPageButton.Text = "Deposit";
            DepositPageButton.UseVisualStyleBackColor = true;
            DepositPageButton.Click += DepositPageButton_Click;
            // 
            // TransactionHomeButton
            // 
            TransactionHomeButton.Location = new Point(17, 30);
            TransactionHomeButton.Name = "TransactionHomeButton";
            TransactionHomeButton.Size = new Size(112, 34);
            TransactionHomeButton.TabIndex = 3;
            TransactionHomeButton.Text = "Home";
            TransactionHomeButton.UseVisualStyleBackColor = true;
            TransactionHomeButton.Click += TransactionHomeButton_Click;
            // 
            // DepositGroupBox
            // 
            DepositGroupBox.Controls.Add(DepositNewBalance);
            DepositGroupBox.Controls.Add(DepositOldBalanceLabel);
            DepositGroupBox.Controls.Add(DepositUpdatedBalanceLabel);
            DepositGroupBox.Controls.Add(DepositPreviousBalanceLabel);
            DepositGroupBox.Controls.Add(DepositStatusLabel);
            DepositGroupBox.Controls.Add(DepositButton);
            DepositGroupBox.Controls.Add(DepositAmountTextBox);
            DepositGroupBox.Controls.Add(DepositAccountNumberTextBox);
            DepositGroupBox.Controls.Add(DepositAmountLabel);
            DepositGroupBox.Controls.Add(DepositAccountNumberLabel);
            DepositGroupBox.Controls.Add(DepositBackButton);
            DepositGroupBox.Location = new Point(0, 0);
            DepositGroupBox.Name = "DepositGroupBox";
            DepositGroupBox.Size = new Size(795, 753);
            DepositGroupBox.TabIndex = 14;
            DepositGroupBox.TabStop = false;
            DepositGroupBox.Enter += DepositGroupBox_Enter;
            // 
            // DepositNewBalance
            // 
            DepositNewBalance.AutoSize = true;
            DepositNewBalance.Location = new Point(157, 524);
            DepositNewBalance.Name = "DepositNewBalance";
            DepositNewBalance.Size = new Size(116, 25);
            DepositNewBalance.TabIndex = 10;
            DepositNewBalance.Text = "New balance:";
            // 
            // DepositOldBalanceLabel
            // 
            DepositOldBalanceLabel.AutoSize = true;
            DepositOldBalanceLabel.Location = new Point(163, 477);
            DepositOldBalanceLabel.Name = "DepositOldBalanceLabel";
            DepositOldBalanceLabel.Size = new Size(110, 25);
            DepositOldBalanceLabel.TabIndex = 9;
            DepositOldBalanceLabel.Text = "Old balance:";
            // 
            // DepositUpdatedBalanceLabel
            // 
            DepositUpdatedBalanceLabel.AutoSize = true;
            DepositUpdatedBalanceLabel.Location = new Point(289, 524);
            DepositUpdatedBalanceLabel.Name = "DepositUpdatedBalanceLabel";
            DepositUpdatedBalanceLabel.Size = new Size(59, 25);
            DepositUpdatedBalanceLabel.TabIndex = 8;
            DepositUpdatedBalanceLabel.Text = "label5";
            // 
            // DepositPreviousBalanceLabel
            // 
            DepositPreviousBalanceLabel.AutoSize = true;
            DepositPreviousBalanceLabel.Location = new Point(289, 477);
            DepositPreviousBalanceLabel.Name = "DepositPreviousBalanceLabel";
            DepositPreviousBalanceLabel.Size = new Size(59, 25);
            DepositPreviousBalanceLabel.TabIndex = 7;
            DepositPreviousBalanceLabel.Text = "label4";
            // 
            // DepositStatusLabel
            // 
            DepositStatusLabel.AutoSize = true;
            DepositStatusLabel.Location = new Point(289, 428);
            DepositStatusLabel.Name = "DepositStatusLabel";
            DepositStatusLabel.Size = new Size(59, 25);
            DepositStatusLabel.TabIndex = 6;
            DepositStatusLabel.Text = "label3";
            // 
            // DepositButton
            // 
            DepositButton.Location = new Point(172, 339);
            DepositButton.Name = "DepositButton";
            DepositButton.Size = new Size(112, 34);
            DepositButton.TabIndex = 5;
            DepositButton.Text = "Deposit";
            DepositButton.UseVisualStyleBackColor = true;
            DepositButton.Click += DepositButton_Click;
            // 
            // DepositAmountTextBox
            // 
            DepositAmountTextBox.Location = new Point(314, 259);
            DepositAmountTextBox.Name = "DepositAmountTextBox";
            DepositAmountTextBox.Size = new Size(150, 31);
            DepositAmountTextBox.TabIndex = 4;
            // 
            // DepositAccountNumberTextBox
            // 
            DepositAccountNumberTextBox.Location = new Point(314, 207);
            DepositAccountNumberTextBox.Name = "DepositAccountNumberTextBox";
            DepositAccountNumberTextBox.Size = new Size(150, 31);
            DepositAccountNumberTextBox.TabIndex = 3;
            // 
            // DepositAmountLabel
            // 
            DepositAmountLabel.AutoSize = true;
            DepositAmountLabel.Location = new Point(96, 265);
            DepositAmountLabel.Name = "DepositAmountLabel";
            DepositAmountLabel.Size = new Size(188, 25);
            DepositAmountLabel.TabIndex = 2;
            DepositAmountLabel.Text = "Enter deposit amount:";
            // 
            // DepositAccountNumberLabel
            // 
            DepositAccountNumberLabel.AutoSize = true;
            DepositAccountNumberLabel.Location = new Point(94, 210);
            DepositAccountNumberLabel.Name = "DepositAccountNumberLabel";
            DepositAccountNumberLabel.Size = new Size(190, 25);
            DepositAccountNumberLabel.TabIndex = 1;
            DepositAccountNumberLabel.Text = "Enter account number:";
            // 
            // DepositBackButton
            // 
            DepositBackButton.Location = new Point(36, 30);
            DepositBackButton.Name = "DepositBackButton";
            DepositBackButton.Size = new Size(112, 34);
            DepositBackButton.TabIndex = 0;
            DepositBackButton.Text = "Back";
            DepositBackButton.UseVisualStyleBackColor = true;
            DepositBackButton.Click += DepositBackButton_Click;
            // 
            // WithdrawGroupBox
            // 
            WithdrawGroupBox.Controls.Add(WithdrawUpdatedBalance);
            WithdrawGroupBox.Controls.Add(WithdrawPreviousBalance);
            WithdrawGroupBox.Controls.Add(WithdrawStatusLabel);
            WithdrawGroupBox.Controls.Add(WithdrawNewBalanceLabel);
            WithdrawGroupBox.Controls.Add(WithdrawOldBalanceLabel);
            WithdrawGroupBox.Controls.Add(WithdrawAmountTextBox);
            WithdrawGroupBox.Controls.Add(WithdrawAccountNumberTextBox);
            WithdrawGroupBox.Controls.Add(WithdrawAmountLabel);
            WithdrawGroupBox.Controls.Add(WithdrawAccountNumberLabel);
            WithdrawGroupBox.Controls.Add(WithdrawButton);
            WithdrawGroupBox.Controls.Add(WithdrawBackButton);
            WithdrawGroupBox.Location = new Point(0, 0);
            WithdrawGroupBox.Name = "WithdrawGroupBox";
            WithdrawGroupBox.Size = new Size(795, 753);
            WithdrawGroupBox.TabIndex = 15;
            WithdrawGroupBox.TabStop = false;
            WithdrawGroupBox.Enter += WithdrawGroupBox_Enter;
            // 
            // WithdrawUpdatedBalance
            // 
            WithdrawUpdatedBalance.AutoSize = true;
            WithdrawUpdatedBalance.Location = new Point(259, 498);
            WithdrawUpdatedBalance.Name = "WithdrawUpdatedBalance";
            WithdrawUpdatedBalance.Size = new Size(59, 25);
            WithdrawUpdatedBalance.TabIndex = 10;
            WithdrawUpdatedBalance.Text = "label7";
            // 
            // WithdrawPreviousBalance
            // 
            WithdrawPreviousBalance.AutoSize = true;
            WithdrawPreviousBalance.Location = new Point(259, 444);
            WithdrawPreviousBalance.Name = "WithdrawPreviousBalance";
            WithdrawPreviousBalance.Size = new Size(59, 25);
            WithdrawPreviousBalance.TabIndex = 9;
            WithdrawPreviousBalance.Text = "label6";
            // 
            // WithdrawStatusLabel
            // 
            WithdrawStatusLabel.AutoSize = true;
            WithdrawStatusLabel.Location = new Point(259, 395);
            WithdrawStatusLabel.Name = "WithdrawStatusLabel";
            WithdrawStatusLabel.Size = new Size(59, 25);
            WithdrawStatusLabel.TabIndex = 8;
            WithdrawStatusLabel.Text = "label5";
            // 
            // WithdrawNewBalanceLabel
            // 
            WithdrawNewBalanceLabel.AutoSize = true;
            WithdrawNewBalanceLabel.Location = new Point(127, 498);
            WithdrawNewBalanceLabel.Name = "WithdrawNewBalanceLabel";
            WithdrawNewBalanceLabel.Size = new Size(115, 25);
            WithdrawNewBalanceLabel.TabIndex = 7;
            WithdrawNewBalanceLabel.Text = "New Balance:";
            // 
            // WithdrawOldBalanceLabel
            // 
            WithdrawOldBalanceLabel.AutoSize = true;
            WithdrawOldBalanceLabel.Location = new Point(133, 443);
            WithdrawOldBalanceLabel.Name = "WithdrawOldBalanceLabel";
            WithdrawOldBalanceLabel.Size = new Size(109, 25);
            WithdrawOldBalanceLabel.TabIndex = 6;
            WithdrawOldBalanceLabel.Text = "Old Balance:";
            // 
            // WithdrawAmountTextBox
            // 
            WithdrawAmountTextBox.Location = new Point(292, 225);
            WithdrawAmountTextBox.Name = "WithdrawAmountTextBox";
            WithdrawAmountTextBox.Size = new Size(150, 31);
            WithdrawAmountTextBox.TabIndex = 5;
            // 
            // WithdrawAccountNumberTextBox
            // 
            WithdrawAccountNumberTextBox.Location = new Point(289, 158);
            WithdrawAccountNumberTextBox.Name = "WithdrawAccountNumberTextBox";
            WithdrawAccountNumberTextBox.Size = new Size(150, 31);
            WithdrawAccountNumberTextBox.TabIndex = 4;
            // 
            // WithdrawAmountLabel
            // 
            WithdrawAmountLabel.AutoSize = true;
            WithdrawAmountLabel.Location = new Point(53, 228);
            WithdrawAmountLabel.Name = "WithdrawAmountLabel";
            WithdrawAmountLabel.Size = new Size(200, 25);
            WithdrawAmountLabel.TabIndex = 3;
            WithdrawAmountLabel.Text = "Enter withdraw amount:";
            // 
            // WithdrawAccountNumberLabel
            // 
            WithdrawAccountNumberLabel.AutoSize = true;
            WithdrawAccountNumberLabel.Location = new Point(62, 161);
            WithdrawAccountNumberLabel.Name = "WithdrawAccountNumberLabel";
            WithdrawAccountNumberLabel.Size = new Size(190, 25);
            WithdrawAccountNumberLabel.TabIndex = 2;
            WithdrawAccountNumberLabel.Text = "Enter account number:";
            // 
            // WithdrawButton
            // 
            WithdrawButton.Location = new Point(172, 321);
            WithdrawButton.Name = "WithdrawButton";
            WithdrawButton.Size = new Size(112, 34);
            WithdrawButton.TabIndex = 1;
            WithdrawButton.Text = "Withdraw";
            WithdrawButton.UseVisualStyleBackColor = true;
            WithdrawButton.Click += WithdrawButton_Click;
            // 
            // WithdrawBackButton
            // 
            WithdrawBackButton.Location = new Point(12, 12);
            WithdrawBackButton.Name = "WithdrawBackButton";
            WithdrawBackButton.Size = new Size(112, 34);
            WithdrawBackButton.TabIndex = 0;
            WithdrawBackButton.Text = "Back";
            WithdrawBackButton.UseVisualStyleBackColor = true;
            WithdrawBackButton.Click += WithdrawBackButton_Click;
            // 
            // TransferGroupBox
            // 
            TransferGroupBox.Controls.Add(TransferReceiverUpdatedBalance);
            TransferGroupBox.Controls.Add(TransferReceiverNewBalance);
            TransferGroupBox.Controls.Add(TransferReceiverPreviousBalance);
            TransferGroupBox.Controls.Add(TransferReceiverOldBalance);
            TransferGroupBox.Controls.Add(TransferSenderUpdatedBalance);
            TransferGroupBox.Controls.Add(TransferSenderNewBalance);
            TransferGroupBox.Controls.Add(TransferSenderPreviousBalance);
            TransferGroupBox.Controls.Add(TransferSenderOldBalanceLabel);
            TransferGroupBox.Controls.Add(TransferStatusLabel);
            TransferGroupBox.Controls.Add(TransferButton);
            TransferGroupBox.Controls.Add(TransferAmountTextBox);
            TransferGroupBox.Controls.Add(TransferAmountLabel);
            TransferGroupBox.Controls.Add(TransferReceiverAccountTextBox);
            TransferGroupBox.Controls.Add(TransferReceiverAccountLabel);
            TransferGroupBox.Controls.Add(TransferSenderAccountTextBox);
            TransferGroupBox.Controls.Add(TransferSenderAccountLabel);
            TransferGroupBox.Controls.Add(TransferBackButton);
            TransferGroupBox.Location = new Point(12, 24);
            TransferGroupBox.Name = "TransferGroupBox";
            TransferGroupBox.Size = new Size(783, 729);
            TransferGroupBox.TabIndex = 15;
            TransferGroupBox.TabStop = false;
            TransferGroupBox.Enter += TransferGroupBox_Enter;
            // 
            // TransferReceiverUpdatedBalance
            // 
            TransferReceiverUpdatedBalance.AutoSize = true;
            TransferReceiverUpdatedBalance.Location = new Point(302, 585);
            TransferReceiverUpdatedBalance.Name = "TransferReceiverUpdatedBalance";
            TransferReceiverUpdatedBalance.Size = new Size(59, 25);
            TransferReceiverUpdatedBalance.TabIndex = 16;
            TransferReceiverUpdatedBalance.Text = "label1";
            // 
            // TransferReceiverNewBalance
            // 
            TransferReceiverNewBalance.AutoSize = true;
            TransferReceiverNewBalance.Location = new Point(84, 585);
            TransferReceiverNewBalance.Name = "TransferReceiverNewBalance";
            TransferReceiverNewBalance.Size = new Size(182, 25);
            TransferReceiverNewBalance.TabIndex = 15;
            TransferReceiverNewBalance.Text = "Receiver new balance:";
            // 
            // TransferReceiverPreviousBalance
            // 
            TransferReceiverPreviousBalance.AutoSize = true;
            TransferReceiverPreviousBalance.Location = new Point(301, 540);
            TransferReceiverPreviousBalance.Name = "TransferReceiverPreviousBalance";
            TransferReceiverPreviousBalance.Size = new Size(59, 25);
            TransferReceiverPreviousBalance.TabIndex = 14;
            TransferReceiverPreviousBalance.Text = "label1";
            // 
            // TransferReceiverOldBalance
            // 
            TransferReceiverOldBalance.AutoSize = true;
            TransferReceiverOldBalance.Location = new Point(96, 539);
            TransferReceiverOldBalance.Name = "TransferReceiverOldBalance";
            TransferReceiverOldBalance.Size = new Size(176, 25);
            TransferReceiverOldBalance.TabIndex = 13;
            TransferReceiverOldBalance.Text = "Receiver old balance:";
            // 
            // TransferSenderUpdatedBalance
            // 
            TransferSenderUpdatedBalance.AutoSize = true;
            TransferSenderUpdatedBalance.Location = new Point(302, 488);
            TransferSenderUpdatedBalance.Name = "TransferSenderUpdatedBalance";
            TransferSenderUpdatedBalance.Size = new Size(59, 25);
            TransferSenderUpdatedBalance.TabIndex = 12;
            TransferSenderUpdatedBalance.Text = "label1";
            // 
            // TransferSenderNewBalance
            // 
            TransferSenderNewBalance.AutoSize = true;
            TransferSenderNewBalance.Location = new Point(99, 488);
            TransferSenderNewBalance.Name = "TransferSenderNewBalance";
            TransferSenderNewBalance.Size = new Size(173, 25);
            TransferSenderNewBalance.TabIndex = 11;
            TransferSenderNewBalance.Text = "Sender new balance:";
            // 
            // TransferSenderPreviousBalance
            // 
            TransferSenderPreviousBalance.AutoSize = true;
            TransferSenderPreviousBalance.Location = new Point(302, 443);
            TransferSenderPreviousBalance.Name = "TransferSenderPreviousBalance";
            TransferSenderPreviousBalance.Size = new Size(59, 25);
            TransferSenderPreviousBalance.TabIndex = 10;
            TransferSenderPreviousBalance.Text = "label1";
            // 
            // TransferSenderOldBalanceLabel
            // 
            TransferSenderOldBalanceLabel.AutoSize = true;
            TransferSenderOldBalanceLabel.Location = new Point(105, 443);
            TransferSenderOldBalanceLabel.Name = "TransferSenderOldBalanceLabel";
            TransferSenderOldBalanceLabel.Size = new Size(167, 25);
            TransferSenderOldBalanceLabel.TabIndex = 9;
            TransferSenderOldBalanceLabel.Text = "Sender old balance:";
            // 
            // TransferStatusLabel
            // 
            TransferStatusLabel.AutoSize = true;
            TransferStatusLabel.Location = new Point(302, 396);
            TransferStatusLabel.Name = "TransferStatusLabel";
            TransferStatusLabel.Size = new Size(59, 25);
            TransferStatusLabel.TabIndex = 8;
            TransferStatusLabel.Text = "label1";
            // 
            // TransferButton
            // 
            TransferButton.Location = new Point(187, 340);
            TransferButton.Name = "TransferButton";
            TransferButton.Size = new Size(112, 34);
            TransferButton.TabIndex = 7;
            TransferButton.Text = "Transfer";
            TransferButton.UseVisualStyleBackColor = true;
            TransferButton.Click += TransferButton_Click;
            // 
            // TransferAmountTextBox
            // 
            TransferAmountTextBox.Location = new Point(340, 272);
            TransferAmountTextBox.Name = "TransferAmountTextBox";
            TransferAmountTextBox.Size = new Size(150, 31);
            TransferAmountTextBox.TabIndex = 6;
            // 
            // TransferAmountLabel
            // 
            TransferAmountLabel.AutoSize = true;
            TransferAmountLabel.Location = new Point(152, 266);
            TransferAmountLabel.Name = "TransferAmountLabel";
            TransferAmountLabel.Size = new Size(147, 25);
            TransferAmountLabel.TabIndex = 5;
            TransferAmountLabel.Text = "Transfer Amount:";
            // 
            // TransferReceiverAccountTextBox
            // 
            TransferReceiverAccountTextBox.Location = new Point(340, 214);
            TransferReceiverAccountTextBox.Name = "TransferReceiverAccountTextBox";
            TransferReceiverAccountTextBox.Size = new Size(150, 31);
            TransferReceiverAccountTextBox.TabIndex = 4;
            // 
            // TransferReceiverAccountLabel
            // 
            TransferReceiverAccountLabel.AutoSize = true;
            TransferReceiverAccountLabel.Location = new Point(73, 211);
            TransferReceiverAccountLabel.Name = "TransferReceiverAccountLabel";
            TransferReceiverAccountLabel.Size = new Size(226, 25);
            TransferReceiverAccountLabel.TabIndex = 3;
            TransferReceiverAccountLabel.Text = "Receiver's account number:";
            // 
            // TransferSenderAccountTextBox
            // 
            TransferSenderAccountTextBox.Location = new Point(340, 153);
            TransferSenderAccountTextBox.Name = "TransferSenderAccountTextBox";
            TransferSenderAccountTextBox.Size = new Size(150, 31);
            TransferSenderAccountTextBox.TabIndex = 2;
            // 
            // TransferSenderAccountLabel
            // 
            TransferSenderAccountLabel.AutoSize = true;
            TransferSenderAccountLabel.Location = new Point(82, 156);
            TransferSenderAccountLabel.Name = "TransferSenderAccountLabel";
            TransferSenderAccountLabel.Size = new Size(217, 25);
            TransferSenderAccountLabel.TabIndex = 1;
            TransferSenderAccountLabel.Text = "Sender's account number:";
            // 
            // TransferBackButton
            // 
            TransferBackButton.Location = new Point(28, 15);
            TransferBackButton.Name = "TransferBackButton";
            TransferBackButton.Size = new Size(112, 34);
            TransferBackButton.TabIndex = 0;
            TransferBackButton.Text = "Back";
            TransferBackButton.UseVisualStyleBackColor = true;
            TransferBackButton.Click += TransferBackButton_Click;
            // 
            // MainPage
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(830, 802);
            Controls.Add(HomeGroupBox);
            Controls.Add(CreateAccountGroupBox);
            Controls.Add(SearchAccountGroupBox);
            Controls.Add(AllAccountsGroupbox);
            Controls.Add(TransactionsGroupBox);
            Controls.Add(DepositGroupBox);
            Controls.Add(WithdrawGroupBox);
            Controls.Add(TransferGroupBox);
            Margin = new Padding(4, 5, 4, 5);
            Name = "MainPage";
            Text = "ATM Banking";
            FormClosing += MainPage_Closing;
            Load += MainPage_Load;
            HomeGroupBox.ResumeLayout(false);
            HomeGroupBox.PerformLayout();
            CreateAccountGroupBox.ResumeLayout(false);
            CreateAccountGroupBox.PerformLayout();
            AllAccountsGroupbox.ResumeLayout(false);
            AllAccountsGroupbox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)AccountsGrid).EndInit();
            SearchAccountGroupBox.ResumeLayout(false);
            SearchAccountGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)SearchAccountsGrid).EndInit();
            TransactionsGroupBox.ResumeLayout(false);
            DepositGroupBox.ResumeLayout(false);
            DepositGroupBox.PerformLayout();
            WithdrawGroupBox.ResumeLayout(false);
            WithdrawGroupBox.PerformLayout();
            TransferGroupBox.ResumeLayout(false);
            TransferGroupBox.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label WelcomeLbl;
        private GroupBox HomeGroupBox;
        private Button CreateAccountPageButton;
        private Button ViewAllAccountsPageButton;
        private Button SearchAccountPageButton;
        private GroupBox CreateAccountGroupBox;
        private Button CreateAccountButton;
        private Label CreateAccountLbl;
        private Button CreateHomeButton;
        private TextBox CreateMinimumBalanceTextBox;
        private Label CreateMinimumBalanceLbl;
        private TextBox CreateInitialDepositTextBox;
        private Label CreateInitialDepositLbl;
        private TextBox CreateCustomerNameTextBox;
        private Label CreateCustomerNameLbl;
        private Label CreateStatusLbl;
        private GroupBox SearchAccountGroupBox;
        private Label SearchStatusLbl;
        private TextBox SearchCustomerIDTextbox;
        private Label SearchWithIDLbl;
        private TextBox SearchCustomerNameTextbox;
        private Label SearchWithNameLbl;
        private Button SearchHomeButton;
        private Button SearchButton;
        private Label SearchAccountLbl;
        private Label SearchEnterIDORNameLbl;
        private GroupBox AllAccountsGroupbox;
        private Label AllAccountsDateCreatedLbl;
        private Label AllAccountsMinimumBalanceLbl;
        private Label AllAccountsCurrentBalanceLbl;
        private Label AllAccountsCustomerNameLbl;
        private Button AllAccountsHomeButton;
        private Label AllAccountsLbl;
        private DataGridView AccountsGrid;
        private Label AllAccountsCustomerIDLbl;
        private DataGridView SearchAccountsGrid;
        private Label AllAccountsCurrentCustomerCreatedLbl;
        private Label AllAccountsCurrentCustomerMinimumBalanceLbl;
        private Label AllAccountsCurrentCustomerBalanceLbl;
        private Label AllAccountsCurrentCustomerNameLbl;
        private Label AllAccountsCurrentCustomerIDLbl;
        private GroupBox TransactionsGroupBox;
        private Button TransactionsPageButton;
        private Button TransactionHomeButton;
        private Button TransferPageButton;
        private Button WithdrawPageButton;
        private Button DepositPageButton;
        private GroupBox DepositGroupBox;
        private GroupBox WithdrawGroupBox;
        private GroupBox TransferGroupBox;
        private Button DepositBackButton;
        private Button WithdrawBackButton;
        private Button TransferBackButton;
        private Label DepositUpdatedBalanceLabel;
        private Label DepositPreviousBalanceLabel;
        private Label DepositStatusLabel;
        private Button DepositButton;
        private TextBox DepositAmountTextBox;
        private TextBox DepositAccountNumberTextBox;
        private Label DepositAmountLabel;
        private Label DepositAccountNumberLabel;
        private Label DepositNewBalance;
        private Label DepositOldBalanceLabel;
        private Label WithdrawUpdatedBalance;
        private Label WithdrawPreviousBalance;
        private Label WithdrawStatusLabel;
        private Label WithdrawNewBalanceLabel;
        private Label WithdrawOldBalanceLabel;
        private TextBox WithdrawAmountTextBox;
        private TextBox WithdrawAccountNumberTextBox;
        private Label WithdrawAmountLabel;
        private Label WithdrawAccountNumberLabel;
        private Button WithdrawButton;
        private Label TransferSenderAccountLabel;
        private TextBox TransferReceiverAccountTextBox;
        private Label TransferReceiverAccountLabel;
        private TextBox TransferSenderAccountTextBox;
        private TextBox TransferAmountTextBox;
        private Label TransferAmountLabel;
        private Button TransferButton;
        private Label TransferSenderOldBalanceLabel;
        private Label TransferStatusLabel;
        private Label TransferSenderNewBalance;
        private Label TransferSenderPreviousBalance;
        private Label TransferReceiverOldBalance;
        private Label TransferSenderUpdatedBalance;
        private Label TransferReceiverNewBalance;
        private Label TransferReceiverPreviousBalance;
        private Label TransferReceiverUpdatedBalance;
    }
}
