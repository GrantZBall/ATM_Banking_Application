namespace AccountManagement
{
    public partial class MainPage : Form
    {
        // initialize accountManager
        AccountManager AccountManager;
        public MainPage()
        {
            InitializeComponent();
        }

        private void MainPage_Load(object sender, EventArgs e)
        {
            // fill the blank account manager and set home groupbox as visible
            AccountManager = new AccountManager();
            AccountManager.LoadAccountsFromJson();
            HomeGroupBox.Visible = true;
        }

        // function to refresh account list on "view all accounts" section
        private void RefreshAllAccountList(List<Account> accountList = null)
        {
            // use provided source for list or if no list, use Get all accounts function
            List<Account> source = accountList ?? AccountManager.GetAllAccounts();

            AccountsGrid.DataSource = null;
            AccountsGrid.DataSource = source;

            // Set column Balance and minimum balance to "c" = currency
            if (AccountsGrid.Columns["Balance"] != null)
                AccountsGrid.Columns["Balance"].DefaultCellStyle.Format = "c";
            if (AccountsGrid.Columns["MinimumBalance"] != null)
                AccountsGrid.Columns["MinimumBalance"].DefaultCellStyle.Format = "c";
        }

        // function to refresh account list on "search account" section
        private void RefreshSearchAccountList(List<Account> accountList = null)
        {
            // use provided source for list
            List<Account> source = accountList;

            SearchAccountsGrid.DataSource = null;
            SearchAccountsGrid.DataSource = source;

            // Set column Balance and minimum balance to "c" = currency
            if (SearchAccountsGrid.Columns["Balance"] != null)
                SearchAccountsGrid.Columns["Balance"].DefaultCellStyle.Format = "c";
            if (SearchAccountsGrid.Columns["Minimum Balance"] != null)
                SearchAccountsGrid.Columns["Minimum Balance"].DefaultCellStyle.Format = "c";
        }

        // All buttons to load each page -------------------------------------------------------------------------------------
        private void CreateAccountPageButton_Click(object sender, EventArgs e)
        {
            // Set create page visible and home as not visible
            HomeGroupBox.Visible = false;
            CreateAccountGroupBox.Visible = true;

            // make textboxes empty
            CreateCustomerNameTextBox.Text = string.Empty;
            CreateInitialDepositTextBox.Text = string.Empty;
            CreateMinimumBalanceTextBox.Text = string.Empty;
            CreateStatusLbl.Text = string.Empty;
        }

        private void SearchAccountPageButton_Click(object sender, EventArgs e)
        {
            // Set search page visible and home as not visible
            HomeGroupBox.Visible = false;
            SearchAccountGroupBox.Visible = true;
            RefreshSearchAccountList();

            // make textboxes empty
            SearchStatusLbl.Text = string.Empty;
            SearchCustomerIDTextbox.Text = string.Empty;
            SearchCustomerNameTextbox.Text = string.Empty;
        }
        private void ViewAllAccountsPageButton_Click(object sender, EventArgs e)
        {
            // Set view all accounts page visible and home as not visible
            HomeGroupBox.Visible = false;
            AllAccountsGroupbox.Visible = true;
            RefreshAllAccountList();

            // make textboxes empty
            AllAccountsCurrentCustomerIDLbl.Text = string.Empty;
            AllAccountsCurrentCustomerNameLbl.Text = string.Empty;
            AllAccountsCurrentCustomerBalanceLbl.Text = string.Empty;
            AllAccountsCurrentCustomerMinimumBalanceLbl.Text = string.Empty;
            AllAccountsCurrentCustomerCreatedLbl.Text = string.Empty;
        }

        // All Home Buttons to return to home page ------------------------------------------------------------------
        private void CreateHomeButton_Click(object sender, EventArgs e)
        {
            // Set home as visible and create to invisible
            HomeGroupBox.Visible = true;
            CreateAccountGroupBox.Visible = false;
        }

        private void SearchHomeButton_Click(object sender, EventArgs e)
        {
            // Set home as visible and search to invisible
            HomeGroupBox.Visible = true;
            SearchAccountGroupBox.Visible = false;
        }

        private void AllAccountsHomeButton_Click(object sender, EventArgs e)
        {
            // Set home as visible and All accounts to invisible
            HomeGroupBox.Visible = true;
            AllAccountsGroupbox.Visible = false;
        }

        private void CreateAccountButton_Click(object sender, EventArgs e)
        {
            // runs ValidateInput() to ensure proper inputs
            if (!(AccountManager.ValidateInput(
                CreateCustomerNameTextBox.Text,
                CreateInitialDepositTextBox.Text,
                CreateMinimumBalanceTextBox.Text,
                out decimal Balance,
                out decimal MinimumBalance,
                out string error)))
            {
                // if invalid input, show error and return
                CreateStatusLbl.ForeColor = Color.Red;
                CreateStatusLbl.Text = error;
                return;
            }

            // create account from information given
            if (AccountManager.CreateAccount(
                CreateCustomerNameTextBox.Text,
                Balance,
                MinimumBalance,
                out string NewAccountNumber,
                out error))
            {
                // show success message
                CreateStatusLbl.ForeColor = Color.Green;
                CreateStatusLbl.Text = $"Successfully created account. Account Name and Number: {CreateCustomerNameTextBox.Text} | {NewAccountNumber}";
            }
            else
            {
                // if failed to create account, show error
                CreateStatusLbl.ForeColor = Color.Red;
                CreateStatusLbl.Text = error;
            }
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            // declare variables for shortcuts later
            string ID = SearchCustomerIDTextbox.Text;
            string Name = SearchCustomerNameTextbox.Text;
            bool NameAndIDSearch = false;
            bool NameSearch = false;

            SearchStatusLbl.Text = string.Empty;

            // if statements to check which textbox is filled
            if (!string.IsNullOrWhiteSpace(Name))
            {
                if (!string.IsNullOrWhiteSpace(ID))
                {
                    NameAndIDSearch = true;
                }
                NameSearch = true;
            }

            // display error if both are blank
            if (string.IsNullOrWhiteSpace(ID) && string.IsNullOrWhiteSpace(Name))
            {
                SearchStatusLbl.ForeColor = Color.Red;
                SearchStatusLbl.Text = "Please enter ID and/or Name to search";
                return;
            }

            // If statements to determine which status message to show based on which textbox is filled
            List<Account> Match = AccountManager.FindAccount(Name, ID, NameSearch, NameAndIDSearch);

            SearchStatusLbl.ForeColor = Color.Black;
            if (NameAndIDSearch == true && Match != null)
                SearchStatusLbl.Text = $"Found {Match.Count()} account(s) with Name and ID matching: {Name} | {ID}";
            else if (NameSearch && Match != null)
                SearchStatusLbl.Text = $"Found {Match.Count()} account(s) with Name matching: {Name}";
            else if (Match != null)
                SearchStatusLbl.Text = $"Found {Match.Count()} account(s) with ID matching: {ID}";

            RefreshSearchAccountList(Match);
        }

        private void AccountsGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // function to take data from selected cell and show its data
            if (e.RowIndex >= 0)
            {
                Account selectedAccount = AccountsGrid.Rows[e.RowIndex].DataBoundItem as Account;
                if (selectedAccount != null)
                {
                    // Set all the textboxes to have the information from the account list
                    AllAccountsCurrentCustomerIDLbl.Text = selectedAccount.AccountNumber;
                    AllAccountsCurrentCustomerNameLbl.Text = selectedAccount.CustomerName;
                    AllAccountsCurrentCustomerBalanceLbl.Text = selectedAccount.Balance.ToString("C");
                    AllAccountsCurrentCustomerMinimumBalanceLbl.Text = selectedAccount.MinimumBalance.ToString("C");
                    AllAccountsCurrentCustomerCreatedLbl.Text = selectedAccount.DateCreated.ToString("f");
                }
            }
        }

        private void MainPage_Closing(object sender, FormClosingEventArgs e)
        {
            // function to save all accounts when closing
            AccountManager.SaveAccountsToJson();
        }
    }
}
