﻿namespace AccountManagement
{
    partial class MainPage
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            WelcomeLbl = new Label();
            HomeGroupBox = new GroupBox();
            ViewAllAccountsPageButton = new Button();
            SearchAccountPageButton = new Button();
            CreateAccountPageButton = new Button();
            CreateAccountGroupBox = new GroupBox();
            CreateStatusLbl = new Label();
            CreateMinimumBalanceTextBox = new TextBox();
            CreateMinimumBalanceLbl = new Label();
            CreateInitialDepositTextBox = new TextBox();
            CreateInitialDepositLbl = new Label();
            CreateCustomerNameTextBox = new TextBox();
            CreateCustomerNameLbl = new Label();
            CreateHomeButton = new Button();
            CreateAccountButton = new Button();
            CreateAccountLbl = new Label();
            AllAccountsGroupbox = new GroupBox();
            AllAccountsCurrentCustomerIDLbl = new Label();
            AllAccountsCurrentCustomerCreatedLbl = new Label();
            AllAccountsCurrentCustomerMinimumBalanceLbl = new Label();
            AllAccountsCurrentCustomerBalanceLbl = new Label();
            AllAccountsCurrentCustomerNameLbl = new Label();
            AllAccountsCustomerIDLbl = new Label();
            AccountsGrid = new DataGridView();
            AllAccountsDateCreatedLbl = new Label();
            AllAccountsMinimumBalanceLbl = new Label();
            AllAccountsCurrentBalanceLbl = new Label();
            AllAccountsCustomerNameLbl = new Label();
            AllAccountsHomeButton = new Button();
            AllAccountsLbl = new Label();
            SearchAccountGroupBox = new GroupBox();
            SearchEnterIDORNameLbl = new Label();
            SearchAccountsGrid = new DataGridView();
            SearchStatusLbl = new Label();
            SearchCustomerIDTextbox = new TextBox();
            SearchWithIDLbl = new Label();
            SearchCustomerNameTextbox = new TextBox();
            SearchWithNameLbl = new Label();
            SearchHomeButton = new Button();
            SearchButton = new Button();
            SearchAccountLbl = new Label();
            HomeGroupBox.SuspendLayout();
            CreateAccountGroupBox.SuspendLayout();
            AllAccountsGroupbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)AccountsGrid).BeginInit();
            SearchAccountGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)SearchAccountsGrid).BeginInit();
            SuspendLayout();
            // 
            // WelcomeLbl
            // 
            WelcomeLbl.AutoSize = true;
            WelcomeLbl.Font = new Font("Sylfaen", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            WelcomeLbl.Location = new Point(80, 76);
            WelcomeLbl.Name = "WelcomeLbl";
            WelcomeLbl.Size = new Size(391, 31);
            WelcomeLbl.TabIndex = 0;
            WelcomeLbl.Text = "Thank you for using ATM Banking";
            // 
            // HomeGroupBox
            // 
            HomeGroupBox.Controls.Add(ViewAllAccountsPageButton);
            HomeGroupBox.Controls.Add(SearchAccountPageButton);
            HomeGroupBox.Controls.Add(CreateAccountPageButton);
            HomeGroupBox.Controls.Add(WelcomeLbl);
            HomeGroupBox.Location = new Point(12, 12);
            HomeGroupBox.Name = "HomeGroupBox";
            HomeGroupBox.Size = new Size(557, 457);
            HomeGroupBox.TabIndex = 1;
            HomeGroupBox.TabStop = false;
            HomeGroupBox.Visible = false;
            // 
            // ViewAllAccountsPageButton
            // 
            ViewAllAccountsPageButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewAllAccountsPageButton.Location = new Point(174, 267);
            ViewAllAccountsPageButton.Name = "ViewAllAccountsPageButton";
            ViewAllAccountsPageButton.Size = new Size(208, 43);
            ViewAllAccountsPageButton.TabIndex = 3;
            ViewAllAccountsPageButton.Text = "View All Accounts";
            ViewAllAccountsPageButton.UseVisualStyleBackColor = true;
            ViewAllAccountsPageButton.Click += ViewAllAccountsPageButton_Click;
            // 
            // SearchAccountPageButton
            // 
            SearchAccountPageButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchAccountPageButton.Location = new Point(174, 218);
            SearchAccountPageButton.Name = "SearchAccountPageButton";
            SearchAccountPageButton.Size = new Size(208, 43);
            SearchAccountPageButton.TabIndex = 2;
            SearchAccountPageButton.Text = "Search Account";
            SearchAccountPageButton.UseVisualStyleBackColor = true;
            SearchAccountPageButton.Click += SearchAccountPageButton_Click;
            // 
            // CreateAccountPageButton
            // 
            CreateAccountPageButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateAccountPageButton.Location = new Point(174, 169);
            CreateAccountPageButton.Name = "CreateAccountPageButton";
            CreateAccountPageButton.Size = new Size(208, 43);
            CreateAccountPageButton.TabIndex = 1;
            CreateAccountPageButton.Text = "Create Account";
            CreateAccountPageButton.UseVisualStyleBackColor = true;
            CreateAccountPageButton.Click += CreateAccountPageButton_Click;
            // 
            // CreateAccountGroupBox
            // 
            CreateAccountGroupBox.Controls.Add(CreateStatusLbl);
            CreateAccountGroupBox.Controls.Add(CreateMinimumBalanceTextBox);
            CreateAccountGroupBox.Controls.Add(CreateMinimumBalanceLbl);
            CreateAccountGroupBox.Controls.Add(CreateInitialDepositTextBox);
            CreateAccountGroupBox.Controls.Add(CreateInitialDepositLbl);
            CreateAccountGroupBox.Controls.Add(CreateCustomerNameTextBox);
            CreateAccountGroupBox.Controls.Add(CreateCustomerNameLbl);
            CreateAccountGroupBox.Controls.Add(CreateHomeButton);
            CreateAccountGroupBox.Controls.Add(CreateAccountButton);
            CreateAccountGroupBox.Controls.Add(CreateAccountLbl);
            CreateAccountGroupBox.Location = new Point(12, 12);
            CreateAccountGroupBox.Name = "CreateAccountGroupBox";
            CreateAccountGroupBox.Size = new Size(557, 457);
            CreateAccountGroupBox.TabIndex = 4;
            CreateAccountGroupBox.TabStop = false;
            CreateAccountGroupBox.Visible = false;
            // 
            // CreateStatusLbl
            // 
            CreateStatusLbl.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CreateStatusLbl.Location = new Point(6, 360);
            CreateStatusLbl.Name = "CreateStatusLbl";
            CreateStatusLbl.Size = new Size(545, 50);
            CreateStatusLbl.TabIndex = 11;
            CreateStatusLbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // CreateMinimumBalanceTextBox
            // 
            CreateMinimumBalanceTextBox.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CreateMinimumBalanceTextBox.Location = new Point(288, 218);
            CreateMinimumBalanceTextBox.Name = "CreateMinimumBalanceTextBox";
            CreateMinimumBalanceTextBox.PlaceholderText = "Ex. 200";
            CreateMinimumBalanceTextBox.Size = new Size(188, 33);
            CreateMinimumBalanceTextBox.TabIndex = 10;
            // 
            // CreateMinimumBalanceLbl
            // 
            CreateMinimumBalanceLbl.AutoSize = true;
            CreateMinimumBalanceLbl.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateMinimumBalanceLbl.Location = new Point(80, 221);
            CreateMinimumBalanceLbl.Name = "CreateMinimumBalanceLbl";
            CreateMinimumBalanceLbl.Size = new Size(202, 25);
            CreateMinimumBalanceLbl.TabIndex = 9;
            CreateMinimumBalanceLbl.Text = "Minimum Balance  . . .";
            // 
            // CreateInitialDepositTextBox
            // 
            CreateInitialDepositTextBox.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CreateInitialDepositTextBox.Location = new Point(288, 179);
            CreateInitialDepositTextBox.Name = "CreateInitialDepositTextBox";
            CreateInitialDepositTextBox.PlaceholderText = "Ex. 1500";
            CreateInitialDepositTextBox.Size = new Size(188, 33);
            CreateInitialDepositTextBox.TabIndex = 8;
            // 
            // CreateInitialDepositLbl
            // 
            CreateInitialDepositLbl.AutoSize = true;
            CreateInitialDepositLbl.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateInitialDepositLbl.Location = new Point(80, 182);
            CreateInitialDepositLbl.Name = "CreateInitialDepositLbl";
            CreateInitialDepositLbl.Size = new Size(202, 25);
            CreateInitialDepositLbl.TabIndex = 7;
            CreateInitialDepositLbl.Text = "Initial Deposit . . . . . . .";
            // 
            // CreateCustomerNameTextBox
            // 
            CreateCustomerNameTextBox.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CreateCustomerNameTextBox.Location = new Point(288, 138);
            CreateCustomerNameTextBox.Name = "CreateCustomerNameTextBox";
            CreateCustomerNameTextBox.PlaceholderText = "Ex. John Smith";
            CreateCustomerNameTextBox.Size = new Size(188, 33);
            CreateCustomerNameTextBox.TabIndex = 6;
            // 
            // CreateCustomerNameLbl
            // 
            CreateCustomerNameLbl.AutoSize = true;
            CreateCustomerNameLbl.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateCustomerNameLbl.Location = new Point(80, 141);
            CreateCustomerNameLbl.Name = "CreateCustomerNameLbl";
            CreateCustomerNameLbl.Size = new Size(202, 25);
            CreateCustomerNameLbl.TabIndex = 5;
            CreateCustomerNameLbl.Text = "Customer Name . . . . .";
            // 
            // CreateHomeButton
            // 
            CreateHomeButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateHomeButton.Location = new Point(6, 17);
            CreateHomeButton.Name = "CreateHomeButton";
            CreateHomeButton.Size = new Size(81, 43);
            CreateHomeButton.TabIndex = 4;
            CreateHomeButton.Text = "Home";
            CreateHomeButton.UseVisualStyleBackColor = true;
            CreateHomeButton.Click += CreateHomeButton_Click;
            // 
            // CreateAccountButton
            // 
            CreateAccountButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateAccountButton.Location = new Point(174, 287);
            CreateAccountButton.Name = "CreateAccountButton";
            CreateAccountButton.Size = new Size(208, 43);
            CreateAccountButton.TabIndex = 1;
            CreateAccountButton.Text = "Create Account";
            CreateAccountButton.UseVisualStyleBackColor = true;
            CreateAccountButton.Click += CreateAccountButton_Click;
            // 
            // CreateAccountLbl
            // 
            CreateAccountLbl.AutoSize = true;
            CreateAccountLbl.Font = new Font("Sylfaen", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreateAccountLbl.Location = new Point(184, 29);
            CreateAccountLbl.Name = "CreateAccountLbl";
            CreateAccountLbl.Size = new Size(185, 31);
            CreateAccountLbl.TabIndex = 0;
            CreateAccountLbl.Text = "Create Account";
            // 
            // AllAccountsGroupbox
            // 
            AllAccountsGroupbox.Controls.Add(AllAccountsCurrentCustomerIDLbl);
            AllAccountsGroupbox.Controls.Add(AllAccountsCurrentCustomerCreatedLbl);
            AllAccountsGroupbox.Controls.Add(AllAccountsCurrentCustomerMinimumBalanceLbl);
            AllAccountsGroupbox.Controls.Add(AllAccountsCurrentCustomerBalanceLbl);
            AllAccountsGroupbox.Controls.Add(AllAccountsCurrentCustomerNameLbl);
            AllAccountsGroupbox.Controls.Add(AllAccountsCustomerIDLbl);
            AllAccountsGroupbox.Controls.Add(AccountsGrid);
            AllAccountsGroupbox.Controls.Add(AllAccountsDateCreatedLbl);
            AllAccountsGroupbox.Controls.Add(AllAccountsMinimumBalanceLbl);
            AllAccountsGroupbox.Controls.Add(AllAccountsCurrentBalanceLbl);
            AllAccountsGroupbox.Controls.Add(AllAccountsCustomerNameLbl);
            AllAccountsGroupbox.Controls.Add(AllAccountsHomeButton);
            AllAccountsGroupbox.Controls.Add(AllAccountsLbl);
            AllAccountsGroupbox.Location = new Point(12, 12);
            AllAccountsGroupbox.Name = "AllAccountsGroupbox";
            AllAccountsGroupbox.Size = new Size(557, 457);
            AllAccountsGroupbox.TabIndex = 12;
            AllAccountsGroupbox.TabStop = false;
            AllAccountsGroupbox.Visible = false;
            // 
            // AllAccountsCurrentCustomerIDLbl
            // 
            AllAccountsCurrentCustomerIDLbl.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AllAccountsCurrentCustomerIDLbl.Location = new Point(163, 76);
            AllAccountsCurrentCustomerIDLbl.Name = "AllAccountsCurrentCustomerIDLbl";
            AllAccountsCurrentCustomerIDLbl.Size = new Size(388, 20);
            AllAccountsCurrentCustomerIDLbl.TabIndex = 19;
            // 
            // AllAccountsCurrentCustomerCreatedLbl
            // 
            AllAccountsCurrentCustomerCreatedLbl.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AllAccountsCurrentCustomerCreatedLbl.Location = new Point(163, 176);
            AllAccountsCurrentCustomerCreatedLbl.Name = "AllAccountsCurrentCustomerCreatedLbl";
            AllAccountsCurrentCustomerCreatedLbl.Size = new Size(388, 20);
            AllAccountsCurrentCustomerCreatedLbl.TabIndex = 18;
            // 
            // AllAccountsCurrentCustomerMinimumBalanceLbl
            // 
            AllAccountsCurrentCustomerMinimumBalanceLbl.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AllAccountsCurrentCustomerMinimumBalanceLbl.Location = new Point(163, 151);
            AllAccountsCurrentCustomerMinimumBalanceLbl.Name = "AllAccountsCurrentCustomerMinimumBalanceLbl";
            AllAccountsCurrentCustomerMinimumBalanceLbl.Size = new Size(388, 20);
            AllAccountsCurrentCustomerMinimumBalanceLbl.TabIndex = 17;
            // 
            // AllAccountsCurrentCustomerBalanceLbl
            // 
            AllAccountsCurrentCustomerBalanceLbl.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AllAccountsCurrentCustomerBalanceLbl.Location = new Point(163, 126);
            AllAccountsCurrentCustomerBalanceLbl.Name = "AllAccountsCurrentCustomerBalanceLbl";
            AllAccountsCurrentCustomerBalanceLbl.Size = new Size(388, 20);
            AllAccountsCurrentCustomerBalanceLbl.TabIndex = 16;
            // 
            // AllAccountsCurrentCustomerNameLbl
            // 
            AllAccountsCurrentCustomerNameLbl.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AllAccountsCurrentCustomerNameLbl.Location = new Point(163, 102);
            AllAccountsCurrentCustomerNameLbl.Name = "AllAccountsCurrentCustomerNameLbl";
            AllAccountsCurrentCustomerNameLbl.Size = new Size(388, 20);
            AllAccountsCurrentCustomerNameLbl.TabIndex = 15;
            // 
            // AllAccountsCustomerIDLbl
            // 
            AllAccountsCustomerIDLbl.AutoSize = true;
            AllAccountsCustomerIDLbl.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AllAccountsCustomerIDLbl.Location = new Point(6, 76);
            AllAccountsCustomerIDLbl.Name = "AllAccountsCustomerIDLbl";
            AllAccountsCustomerIDLbl.Size = new Size(158, 20);
            AllAccountsCustomerIDLbl.TabIndex = 14;
            AllAccountsCustomerIDLbl.Text = "Account Number . . . .";
            // 
            // AccountsGrid
            // 
            AccountsGrid.AccessibleRole = AccessibleRole.None;
            AccountsGrid.AllowUserToAddRows = false;
            AccountsGrid.AllowUserToDeleteRows = false;
            AccountsGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            AccountsGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            AccountsGrid.ImeMode = ImeMode.NoControl;
            AccountsGrid.Location = new Point(6, 202);
            AccountsGrid.MultiSelect = false;
            AccountsGrid.Name = "AccountsGrid";
            AccountsGrid.ReadOnly = true;
            AccountsGrid.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            AccountsGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            AccountsGrid.Size = new Size(545, 249);
            AccountsGrid.TabIndex = 13;
            AccountsGrid.TabStop = false;
            AccountsGrid.CellClick += AccountsGrid_CellClick;
            // 
            // AllAccountsDateCreatedLbl
            // 
            AllAccountsDateCreatedLbl.AutoSize = true;
            AllAccountsDateCreatedLbl.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AllAccountsDateCreatedLbl.Location = new Point(6, 176);
            AllAccountsDateCreatedLbl.Name = "AllAccountsDateCreatedLbl";
            AllAccountsDateCreatedLbl.Size = new Size(158, 20);
            AllAccountsDateCreatedLbl.TabIndex = 12;
            AllAccountsDateCreatedLbl.Text = "Date Created  . . . . . . .";
            // 
            // AllAccountsMinimumBalanceLbl
            // 
            AllAccountsMinimumBalanceLbl.AutoSize = true;
            AllAccountsMinimumBalanceLbl.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AllAccountsMinimumBalanceLbl.Location = new Point(6, 151);
            AllAccountsMinimumBalanceLbl.Name = "AllAccountsMinimumBalanceLbl";
            AllAccountsMinimumBalanceLbl.Size = new Size(160, 20);
            AllAccountsMinimumBalanceLbl.TabIndex = 9;
            AllAccountsMinimumBalanceLbl.Text = "Minimum Balance  . . .";
            // 
            // AllAccountsCurrentBalanceLbl
            // 
            AllAccountsCurrentBalanceLbl.AutoSize = true;
            AllAccountsCurrentBalanceLbl.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AllAccountsCurrentBalanceLbl.Location = new Point(6, 126);
            AllAccountsCurrentBalanceLbl.Name = "AllAccountsCurrentBalanceLbl";
            AllAccountsCurrentBalanceLbl.Size = new Size(158, 20);
            AllAccountsCurrentBalanceLbl.TabIndex = 7;
            AllAccountsCurrentBalanceLbl.Text = "Current Balance . . . . .";
            // 
            // AllAccountsCustomerNameLbl
            // 
            AllAccountsCustomerNameLbl.AutoSize = true;
            AllAccountsCustomerNameLbl.Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold);
            AllAccountsCustomerNameLbl.Location = new Point(6, 101);
            AllAccountsCustomerNameLbl.Name = "AllAccountsCustomerNameLbl";
            AllAccountsCustomerNameLbl.Size = new Size(159, 20);
            AllAccountsCustomerNameLbl.TabIndex = 5;
            AllAccountsCustomerNameLbl.Text = "Customer Name . . . . .";
            // 
            // AllAccountsHomeButton
            // 
            AllAccountsHomeButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AllAccountsHomeButton.Location = new Point(6, 17);
            AllAccountsHomeButton.Name = "AllAccountsHomeButton";
            AllAccountsHomeButton.Size = new Size(81, 43);
            AllAccountsHomeButton.TabIndex = 4;
            AllAccountsHomeButton.Text = "Home";
            AllAccountsHomeButton.UseVisualStyleBackColor = true;
            AllAccountsHomeButton.Click += AllAccountsHomeButton_Click;
            // 
            // AllAccountsLbl
            // 
            AllAccountsLbl.AutoSize = true;
            AllAccountsLbl.Font = new Font("Sylfaen", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AllAccountsLbl.Location = new Point(184, 29);
            AllAccountsLbl.Name = "AllAccountsLbl";
            AllAccountsLbl.Size = new Size(155, 31);
            AllAccountsLbl.TabIndex = 0;
            AllAccountsLbl.Text = "All Accounts";
            // 
            // SearchAccountGroupBox
            // 
            SearchAccountGroupBox.Controls.Add(SearchEnterIDORNameLbl);
            SearchAccountGroupBox.Controls.Add(SearchAccountsGrid);
            SearchAccountGroupBox.Controls.Add(SearchStatusLbl);
            SearchAccountGroupBox.Controls.Add(SearchCustomerIDTextbox);
            SearchAccountGroupBox.Controls.Add(SearchWithIDLbl);
            SearchAccountGroupBox.Controls.Add(SearchCustomerNameTextbox);
            SearchAccountGroupBox.Controls.Add(SearchWithNameLbl);
            SearchAccountGroupBox.Controls.Add(SearchHomeButton);
            SearchAccountGroupBox.Controls.Add(SearchButton);
            SearchAccountGroupBox.Controls.Add(SearchAccountLbl);
            SearchAccountGroupBox.Location = new Point(12, 12);
            SearchAccountGroupBox.Name = "SearchAccountGroupBox";
            SearchAccountGroupBox.Size = new Size(557, 457);
            SearchAccountGroupBox.TabIndex = 12;
            SearchAccountGroupBox.TabStop = false;
            SearchAccountGroupBox.Visible = false;
            // 
            // SearchEnterIDORNameLbl
            // 
            SearchEnterIDORNameLbl.AutoSize = true;
            SearchEnterIDORNameLbl.Location = new Point(145, 61);
            SearchEnterIDORNameLbl.Name = "SearchEnterIDORNameLbl";
            SearchEnterIDORNameLbl.Size = new Size(268, 15);
            SearchEnterIDORNameLbl.TabIndex = 12;
            SearchEnterIDORNameLbl.Text = "Please enter Customer Name and/or Customer ID";
            // 
            // SearchAccountsGrid
            // 
            SearchAccountsGrid.AccessibleRole = AccessibleRole.None;
            SearchAccountsGrid.AllowUserToAddRows = false;
            SearchAccountsGrid.AllowUserToDeleteRows = false;
            SearchAccountsGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            SearchAccountsGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            SearchAccountsGrid.ImeMode = ImeMode.NoControl;
            SearchAccountsGrid.Location = new Point(6, 269);
            SearchAccountsGrid.MultiSelect = false;
            SearchAccountsGrid.Name = "SearchAccountsGrid";
            SearchAccountsGrid.ReadOnly = true;
            SearchAccountsGrid.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            SearchAccountsGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            SearchAccountsGrid.Size = new Size(545, 182);
            SearchAccountsGrid.TabIndex = 0;
            SearchAccountsGrid.TabStop = false;
            // 
            // SearchStatusLbl
            // 
            SearchStatusLbl.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            SearchStatusLbl.Location = new Point(0, 240);
            SearchStatusLbl.Name = "SearchStatusLbl";
            SearchStatusLbl.Size = new Size(551, 24);
            SearchStatusLbl.TabIndex = 11;
            SearchStatusLbl.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // SearchCustomerIDTextbox
            // 
            SearchCustomerIDTextbox.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            SearchCustomerIDTextbox.Location = new Point(288, 135);
            SearchCustomerIDTextbox.Name = "SearchCustomerIDTextbox";
            SearchCustomerIDTextbox.PlaceholderText = "Ex. 1001";
            SearchCustomerIDTextbox.Size = new Size(188, 33);
            SearchCustomerIDTextbox.TabIndex = 8;
            // 
            // SearchWithIDLbl
            // 
            SearchWithIDLbl.AutoSize = true;
            SearchWithIDLbl.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchWithIDLbl.Location = new Point(80, 138);
            SearchWithIDLbl.Name = "SearchWithIDLbl";
            SearchWithIDLbl.Size = new Size(200, 25);
            SearchWithIDLbl.TabIndex = 7;
            SearchWithIDLbl.Text = "Customer ID . . . . . . . .";
            // 
            // SearchCustomerNameTextbox
            // 
            SearchCustomerNameTextbox.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            SearchCustomerNameTextbox.Location = new Point(288, 94);
            SearchCustomerNameTextbox.Name = "SearchCustomerNameTextbox";
            SearchCustomerNameTextbox.PlaceholderText = "Ex. John Smith";
            SearchCustomerNameTextbox.Size = new Size(188, 33);
            SearchCustomerNameTextbox.TabIndex = 6;
            // 
            // SearchWithNameLbl
            // 
            SearchWithNameLbl.AutoSize = true;
            SearchWithNameLbl.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchWithNameLbl.Location = new Point(80, 97);
            SearchWithNameLbl.Name = "SearchWithNameLbl";
            SearchWithNameLbl.Size = new Size(202, 25);
            SearchWithNameLbl.TabIndex = 5;
            SearchWithNameLbl.Text = "Customer Name . . . . .";
            // 
            // SearchHomeButton
            // 
            SearchHomeButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchHomeButton.Location = new Point(6, 17);
            SearchHomeButton.Name = "SearchHomeButton";
            SearchHomeButton.Size = new Size(81, 43);
            SearchHomeButton.TabIndex = 4;
            SearchHomeButton.Text = "Home";
            SearchHomeButton.UseVisualStyleBackColor = true;
            SearchHomeButton.Click += SearchHomeButton_Click;
            // 
            // SearchButton
            // 
            SearchButton.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchButton.Location = new Point(174, 194);
            SearchButton.Name = "SearchButton";
            SearchButton.Size = new Size(208, 43);
            SearchButton.TabIndex = 1;
            SearchButton.Text = "Search";
            SearchButton.UseVisualStyleBackColor = true;
            SearchButton.Click += SearchButton_Click;
            // 
            // SearchAccountLbl
            // 
            SearchAccountLbl.AutoSize = true;
            SearchAccountLbl.Font = new Font("Sylfaen", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchAccountLbl.Location = new Point(163, 29);
            SearchAccountLbl.Name = "SearchAccountLbl";
            SearchAccountLbl.Size = new Size(230, 31);
            SearchAccountLbl.TabIndex = 0;
            SearchAccountLbl.Text = "Search For Account";
            // 
            // MainPage
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(581, 481);
            Controls.Add(HomeGroupBox);
            Controls.Add(CreateAccountGroupBox);
            Controls.Add(SearchAccountGroupBox);
            Controls.Add(AllAccountsGroupbox);
            Name = "MainPage";
            Text = "ATM Banking";
            FormClosing += MainPage_Closing;
            Load += MainPage_Load;
            HomeGroupBox.ResumeLayout(false);
            HomeGroupBox.PerformLayout();
            CreateAccountGroupBox.ResumeLayout(false);
            CreateAccountGroupBox.PerformLayout();
            AllAccountsGroupbox.ResumeLayout(false);
            AllAccountsGroupbox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)AccountsGrid).EndInit();
            SearchAccountGroupBox.ResumeLayout(false);
            SearchAccountGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)SearchAccountsGrid).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label WelcomeLbl;
        private GroupBox HomeGroupBox;
        private Button CreateAccountPageButton;
        private Button ViewAllAccountsPageButton;
        private Button SearchAccountPageButton;
        private GroupBox CreateAccountGroupBox;
        private Button CreateAccountButton;
        private Label CreateAccountLbl;
        private Button CreateHomeButton;
        private TextBox CreateMinimumBalanceTextBox;
        private Label CreateMinimumBalanceLbl;
        private TextBox CreateInitialDepositTextBox;
        private Label CreateInitialDepositLbl;
        private TextBox CreateCustomerNameTextBox;
        private Label CreateCustomerNameLbl;
        private Label CreateStatusLbl;
        private GroupBox SearchAccountGroupBox;
        private Label SearchStatusLbl;
        private TextBox SearchCustomerIDTextbox;
        private Label SearchWithIDLbl;
        private TextBox SearchCustomerNameTextbox;
        private Label SearchWithNameLbl;
        private Button SearchHomeButton;
        private Button SearchButton;
        private Label SearchAccountLbl;
        private Label SearchEnterIDORNameLbl;
        private GroupBox AllAccountsGroupbox;
        private Label AllAccountsDateCreatedLbl;
        private Label AllAccountsMinimumBalanceLbl;
        private Label AllAccountsCurrentBalanceLbl;
        private Label AllAccountsCustomerNameLbl;
        private Button AllAccountsHomeButton;
        private Label AllAccountsLbl;
        private DataGridView AccountsGrid;
        private Label AllAccountsCustomerIDLbl;
        private DataGridView SearchAccountsGrid;
        private Label AllAccountsCurrentCustomerCreatedLbl;
        private Label AllAccountsCurrentCustomerMinimumBalanceLbl;
        private Label AllAccountsCurrentCustomerBalanceLbl;
        private Label AllAccountsCurrentCustomerNameLbl;
        private Label AllAccountsCurrentCustomerIDLbl;
    }
}
