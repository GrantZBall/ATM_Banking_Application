﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace AccountManagement
{
    public class AccountManager
    {
        // initialize list of accounts and accounts json file
        List<Account> ListOfAccounts;
        string filePath = "UserAccounts.json";

        // reserving space in memory for accounts
        public AccountManager()
        {
            ListOfAccounts = new List<Account>();
        }

        // function to ensure inputs from user when creating account is valid
        public bool ValidateInput(
            string customerName,
            string BalanceTextbox,
            string MinimumBalanceTextbox,
            out decimal ParsedBalance,
            out decimal MinimumBalance,
            out string ErrorMessage)
        {
            // initialize starting values
            ParsedBalance = 0m;
            MinimumBalance = 0m;
            ErrorMessage = string.Empty;

            // if statement to check empty customer name
            if (string.IsNullOrEmpty(customerName))
            {
                ErrorMessage = "Customer Name can not be blank.";
                return false;
            }

            // if statement to ensure valid number for Initial deposit
            if (!(decimal.TryParse(BalanceTextbox, out ParsedBalance)))
            {
                ErrorMessage = "Initial Deposit must be a valid number.";
                return false;
            }

            // if statement to ensure valid number for minimum balance
            if (!(decimal.TryParse(MinimumBalanceTextbox, out MinimumBalance)))
            {
                MinimumBalance = 0;
            }

            // if statement to ensure initial deposit is over the minimum balance
            if (ParsedBalance < MinimumBalance)
            {
                ErrorMessage = "Initial Deposit must be greater than minimum balance requirement.";
                return false;
            }

            // return true if everything is valid
            return true;
        }

        // Function to create a new account
        public bool CreateAccount(
            string CustomerName,
            decimal InitialDeposit,
            decimal MinimumBalance,
            out string AccountNumber,
            out string ErrorMessage)
        {
            // initialize default error message
            ErrorMessage = string.Empty;

            // determine next account number
            int NextUserID = 1001 + ListOfAccounts.Count;
            AccountNumber = NextUserID.ToString();

            // create the new account from account.cs and add it to the list of accounts
            Account NewAccount = new Account(AccountNumber, CustomerName, InitialDeposit, MinimumBalance);
            ListOfAccounts.Add(NewAccount);

            // save all accounts to JSON file and return true
            SaveAccountsToJson();
            return true;
        }

        // function that returns a list of accounts matching search
        public List<Account> FindAccount(string CustomerName, string AccountNumber, bool NameSearch, bool NameAndID)
        {
            // foreach loop to go through accounts and check if it matches
            List<Account> matches = new List<Account>();

            // if statements to see which search method to use
            if (NameSearch)
            {
                if (NameAndID)
                {
                    // search using Name and ID
                    foreach (Account account in ListOfAccounts)
                    {
                        if (account.CustomerName.IndexOf(CustomerName, StringComparison.OrdinalIgnoreCase) != -1 && (account.AccountNumber == AccountNumber))
                            matches.Add(account);
                    }
                }
                // search using Name
                else
                {
                    foreach (Account account in ListOfAccounts)
                    {
                        // if to check if name matches any records and adds to new list
                        if ((account.CustomerName.IndexOf(CustomerName, StringComparison.OrdinalIgnoreCase) != -1))
                            matches.Add(account);
                    }
                }
            }
            // Search using ID
            else
            {
                foreach (Account account in ListOfAccounts)
                {
                    if (account.AccountNumber == AccountNumber)
                        matches.Add(account);
                }
            }
            // return the matching account(s)
            return matches;
        }

        // function to save all accounts to the json file
        public void SaveAccountsToJson()
        {
            var accountDetails = new JsonSerializerOptions { WriteIndented = true, };
            string jsonString = JsonSerializer.Serialize(ListOfAccounts, accountDetails);
            File.WriteAllText(filePath, jsonString);
        }

        // function to load all accounts from the json file
        public void LoadAccountsFromJson()
        {
            string jsonString = File.ReadAllText(filePath);
            ListOfAccounts = JsonSerializer.Deserialize<List<Account>>(jsonString) ?? new List<Account>();
        }

        // function that returns all accounts in json
        public List<Account> GetAllAccounts()
        {
            return ListOfAccounts;
        }
    }
}
